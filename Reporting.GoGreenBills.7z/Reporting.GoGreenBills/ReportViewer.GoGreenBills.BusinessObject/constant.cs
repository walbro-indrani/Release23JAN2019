﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReportViewer.GoGreenBills.BusinessObject
{
    public class constant
    {
        public static string procRevenueReport = "Report.DashboardGetTotalRevenueReportData";
        public static string procCollectionReport = "Report.DashboardGetCollectionReportData";
        public static string procPendingReceivableReport = "Report.DashboardGetPendingReceivableReportData";
        public static string procDenialReport = "Report.DashboardGetDenialReportData";
        public static string procDenialTrendingReport = "Report.DashboardGetDenialTrendingReportData";
        public static string procBillCountReportData = "Report.DashboardGetBillCountReportData";
        public static string procPatientCountReportData = "Report.DashboardGetPatientCountReportData";
        public static string procVisitCountReportData = "Report.DashboardGetVisitCountReportData";
        public static string procPendingReceivableDistributionReport = "Report.DashboardGetPendingReceivableDistributionReportData";
        public static string procDashboardGetAccountReceivableAgingReport = "Report.DashboardGetAccountReceivableAgingReport";
        public static string procDashboardGetAccountReceivableAgingReportDetail= "Report.DashboardGetAccountReceivableAgingReportDetail";
        public static string procDashboardAccountAgingReportDataToExcel = "Report.DashboardGetAccountReceivableAgingReportInExcel";
    }
    public class singleConstant
    {
        public static string specCollectionReport = "Report.DashboardGetCollectionBySpecialty";
        public static string provCollectionReport = "Report.DashboardGetCollectionByProvider";
        public static string insCollectionReport = "Report.DashboardGetCollectionByInsurance";
        public static string specPendingReceivableReport = "Report.DashboardGetPendingReceivableBySpecialty";
        public static string provPendingReceivableReport = "Report.DashboardGetPendingReceivableByProvider";
        public static string insPendingReceivableReport = "Report.DashboardGetPendingReceivableByInsurance";
        public static string specBillingReport = "Report.DashboardGetTotalRevenueBySpecialty";
        public static string provBillingReport = "Report.DashboardGetTotalRevenueByProvider";
        public static string insBillingReport = "Report.DashboardGetTotalRevenueByInsurance";
        public static string procDashboardGetAmountReportData = "Report.DashboardGetAmountReportData";
        public static string insuranceDetailedReceivableReport = "Report.DashboardGetAccountReceivableAgingReportByInsuranceEXCEL";
        public static string accountDetailedReceivableReport = "Report.DashboardGetAccountReceivableAgingReportAccountWiseEXCEL";
        public static string providerDetailedReceivableReport = "Report.DashboardGetAccountReceivableAgingReportProviderWiseEXCEL";
    }

    public class DataDownloadConstants
    {
        public static string specRevenueData = "Report.DashboardGetTotalRevenueBySpecialtyDATA";
        public static string provRevenueData = "Report.DashboardGetTotalRevenueByProviderDATA";
        public static string insurRevenueData = "Report.DashboardGetTotalRevenueByInsuranceDATA";
        public static string vistiSummaryData = "Report.spVisitCollectionSummaryReportDATA";
    }
}

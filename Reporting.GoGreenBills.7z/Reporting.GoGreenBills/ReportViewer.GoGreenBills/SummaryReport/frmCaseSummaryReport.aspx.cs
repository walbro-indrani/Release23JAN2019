﻿using Microsoft.Reporting.WebForms;
using ReportViewer.GoGreenBills.DataLayer;
using ReportViewer.GoGreenBills.ReportingWebService;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services.Protocols;


namespace ReportViewer.GoGreenBills.SummaryReport
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        public static string ReportId="9";
        public static string SubsID = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Items["ReportID"] = ReportId;
            UserControl.UserControl c1 = (UserControl.UserControl)LoadControl("../UserControl/UserControl.ascx");
            placeHolder.Controls.Add(c1);
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string UrlReportServer = ConfigurationManager.AppSettings["ReportServer"].ToString();
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            rptViewer.ServerReport.ReportServerUrl = new Uri(UrlReportServer);
            rptViewer.ServerReport.ReportPath = "/Reporting.GreenYourBills/rptCaseSummary";
            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["UserName"].ToString(), ConfigurationManager.AppSettings["Password"].ToString(), ConfigurationManager.AppSettings["ServerDomain"].ToString());
            rptViewer.ServerReport.ReportServerCredentials = irsc;

            ArrayList reportParam1 = new ArrayList();
            ArrayList reportParam = new ArrayList();

            UserControl.UserControl uc = (UserControl.UserControl)placeHolder.Controls[0];
            string companies = ((List<string>)(Session["Companies"])).Count > 0 ? ((List<string>)(Session["Companies"])).Aggregate((x, y) => x + "," + y) : "";
            reportParam1 = SubscriptionParameter.ReportDefaultParam(uc, Convert.ToInt32(ReportId), companies);

            reportParam = (ArrayList)reportParam1[0];

            ReportParameter[] param = new ReportParameter[reportParam.Count];
            for (int i = 0; i < reportParam.Count; i++)
            {
                param[i] = (ReportParameter)reportParam[i];
            }

            rptViewer.ServerReport.SetParameters(param);
            rptViewer.ServerReport.Refresh();

        }

        public void btnSchedule_Click(object sender, EventArgs e)
        {
            string weekdays = null;
            string months = null;
            string ScheduleType = null;
            string setTime = null;
            string startScheduleDate = null;
            string stopScheduleDate = null;
            string WeeksList = null;
            string MonthsList = null;
            int noOfDays = 1;
            int noOfWeeks = 1;
            string chkMonthsWeek = null;
            string chkMonthsRange = null;
            string checkXml = "";

            ArrayList scheduleParam = new ArrayList();
            ArrayList scheduleParam1 = new ArrayList();

            UserControl.UserControl uc = (UserControl.UserControl)placeHolder.Controls[0];
            string companies = ((List<string>)(Session["Companies"])).Count > 0 ? ((List<string>)(Session["Companies"])).Aggregate((x, y) => x + "," + y) : "";
            scheduleParam1 = SubscriptionParameter.ReportDefaultParam(uc, Convert.ToInt32(ReportId), companies);

            scheduleParam = (ArrayList)scheduleParam1[0];
            if (Daily.Checked)
            {
                ScheduleType = "Daily";
                if (WeekDay.Checked)
                {
                    if (weekdaysun.Checked) { weekdays += "<Sunday>True</Sunday>"; WeeksList += "weekdaysun, "; }
                    if (weekdaymon.Checked) { weekdays += "<Monday>True</Monday>"; WeeksList += "weekdaymon, "; }
                    if (weekdaytue.Checked) { weekdays += "<Tuesday>True</Tuesday>"; WeeksList += "weekdaytue, "; }
                    if (weekdaywed.Checked) { weekdays += "<Wednesday>True</Wednesday>"; WeeksList += "weekdaywed, "; }
                    if (weekdaythu.Checked) { weekdays += "<Thursday>True</Thursday>"; WeeksList += "weekdaythu, "; }
                    if (weekdayfri.Checked) { weekdays += "<Friday>True</Friday>"; WeeksList += "weekdayfri, "; }
                    if (weekdaysat.Checked) { weekdays += "<Saturday>True</Saturday>"; WeeksList += "weekdaysat, "; }

                    WeeksList = WeeksList.Remove(WeeksList.LastIndexOf(","));
                    setTime = timeSchedule.Value;
                    startScheduleDate = startSchedule.Value;

                    if (checkSchedule.Checked)
                    {
                        stopScheduleDate = stopSchedule.Value;
                        checkXml = "<ScheduleDefinition><StartDateTime>" + startScheduleDate + "T" + setTime + "</StartDateTime><EndDate>" + stopScheduleDate + "</EndDate><WeeklyRecurrence><WeeksInterval>1</WeeksInterval><DaysOfWeek>" + weekdays + "</DaysOfWeek></WeeklyRecurrence></ScheduleDefinition>";
                    }
                    else
                    {
                        checkXml = "<ScheduleDefinition><StartDateTime>" + startScheduleDate + "T" + setTime + "</StartDateTime><WeeklyRecurrence><WeeksInterval>1</WeeksInterval><DaysOfWeek>" + weekdays + "</DaysOfWeek></WeeklyRecurrence></ScheduleDefinition>";
                    }
                }
                else if (NoOfDays.Checked)
                {
                    noOfDays = (Convert.ToInt32(txtnoofdays.Value));
                    setTime = timeSchedule.Value;
                    startScheduleDate = startSchedule.Value;

                    if (checkSchedule.Checked)
                    {
                        stopScheduleDate = stopSchedule.Value;
                        checkXml = "<ScheduleDefinition><StartDateTime>" + startScheduleDate + "T" + setTime + "</StartDateTime><EndDate>" + stopScheduleDate + "</EndDate><DailyRecurrence><DaysInterval>" + noOfDays + "</DaysInterval></DailyRecurrence></ScheduleDefinition>";
                    }
                    else
                    {
                        checkXml = "<ScheduleDefinition><StartDateTime>" + startScheduleDate + "T" + setTime + "</StartDateTime><DailyRecurrence><DaysInterval>" + noOfDays + "</DaysInterval></DailyRecurrence></ScheduleDefinition>";
                    }
                }
            }
            else if (Weekly.Checked)
            {
                ScheduleType = "Weekly";
                noOfWeeks = (Convert.ToInt32(txtnoofweeks.Value));

                if (daysun.Checked) { weekdays += "<Sunday>True</Sunday>"; WeeksList += "daysun, "; }
                if (daymon.Checked) { weekdays += "<Monday>True</Monday>"; WeeksList += "daymon, "; }
                if (daytue.Checked) { weekdays += "<Tuesday>True</Tuesday>"; WeeksList += "daytue, "; }
                if (daywed.Checked) { weekdays += "<Wednesday>True</Wednesday>"; WeeksList += "daywed, "; }
                if (daythu.Checked) { weekdays += "<Thursday>True</Thursday>"; WeeksList += "daythu, "; }
                if (dayfri.Checked) { weekdays += "<Friday>True</Friday>"; WeeksList += "dayfri, "; }
                if (daysat.Checked) { weekdays += "<Saturday>True</Saturday>"; WeeksList += "daysat, "; }

                WeeksList = WeeksList.Remove(WeeksList.LastIndexOf(","));
                setTime = timeSchedule.Value;
                startScheduleDate = startSchedule.Value;

                if (checkSchedule.Checked)
                {
                    stopScheduleDate = stopSchedule.Value;
                    checkXml = "<ScheduleDefinition><StartDateTime>" + startScheduleDate + "T" + setTime + "</StartDateTime><EndDate>" + stopScheduleDate + "</EndDate><WeeklyRecurrence><WeeksInterval>" + noOfWeeks + "</WeeksInterval><DaysOfWeek>" + weekdays + "</DaysOfWeek></WeeklyRecurrence></ScheduleDefinition>";
                }
                else
                {
                    checkXml = "<ScheduleDefinition><StartDateTime>" + startScheduleDate + "T" + setTime + "</StartDateTime><WeeklyRecurrence><WeeksInterval>" + noOfWeeks + "</WeeksInterval><DaysOfWeek>" + weekdays + "</DaysOfWeek></WeeklyRecurrence></ScheduleDefinition>";
                }
            }
            else if (Monthly.Checked)
            {
                ScheduleType = "Monthly";
                if (monthJan.Checked) { months += "<January>True</January>"; MonthsList += "monthJan, "; }
                if (monthFeb.Checked) { months += "<February>True</February>"; MonthsList += "monthFeb, "; }
                if (monthMar.Checked) { months += "<March>True</March>"; MonthsList += "monthMar, "; }
                if (monthApr.Checked) { months += "<April>True</April>"; MonthsList += "monthApr, "; }
                if (monthMay.Checked) { months += "<May>True</May>"; MonthsList += "monthMay, "; }
                if (monthJun.Checked) { months += "<June>True</June>"; MonthsList += "monthJun, "; }
                if (monthJul.Checked) { months += "<July>True</July>"; MonthsList += "monthJul, "; }
                if (monthAug.Checked) { months += "<August>True</August>"; MonthsList += "monthAug, "; }
                if (monthSep.Checked) { months += "<September>True</September>"; MonthsList += "monthSep, "; }
                if (monthOct.Checked) { months += "<October>True</October>"; MonthsList += "monthOct, "; }
                if (monthNov.Checked) { months += "<November>True</November>"; MonthsList += "monthNov, "; }
                if (monthDec.Checked) { months += "<December>True</December>"; MonthsList += "monthDec, "; }

                MonthsList = MonthsList.Remove(MonthsList.LastIndexOf(","));

                if (checkMonths.Checked)
                {
                    chkMonthsWeek = monthSchedule.Value;
                    if (monthday1.Checked) { weekdays += "<Sunday>True</Sunday>"; WeeksList += "monthday1, "; }
                    if (monthday2.Checked) { weekdays += "<Monday>True</Monday>"; WeeksList += "monthday2, "; }
                    if (monthday3.Checked) { weekdays += "<Tuesday>True</Tuesday>"; WeeksList += "monthday3, "; }
                    if (monthday4.Checked) { weekdays += "<Wednesday>True</Wednesday>"; WeeksList += "monthday4, "; }
                    if (monthday5.Checked) { weekdays += "<Thursday>True</Thursday>"; WeeksList += "monthday5, "; }
                    if (monthday6.Checked) { weekdays += "<Friday>True</Friday>"; WeeksList += "monthday6, "; }
                    if (monthday7.Checked) { weekdays += "<Saturday>True</Saturday>"; WeeksList += "monthday7, "; }

                    WeeksList = WeeksList.Remove(WeeksList.LastIndexOf(","));
                    setTime = timeSchedule.Value;
                    startScheduleDate = startSchedule.Value;

                    if (checkSchedule.Checked)
                    {
                        stopScheduleDate = stopSchedule.Value;
                        checkXml = "<ScheduleDefinition><StartDateTime>" + startScheduleDate + "T" + setTime + "</StartDateTime><EndDate>" + stopScheduleDate + "</EndDate><MonthlyDOWRecurrence><WhichWeek>" + chkMonthsWeek + "</WhichWeek><DaysOfWeek>" + weekdays + "</DaysOfWeek><MonthsOfYear>" + months + "</MonthsOfYear></MonthlyDOWRecurrence></ScheduleDefinition>";
                    }
                    else
                    {
                        checkXml = "<ScheduleDefinition><StartDateTime>" + startScheduleDate + "T" + setTime + "</StartDateTime><MonthlyDOWRecurrence><WhichWeek>" + chkMonthsWeek + "</WhichWeek><DaysOfWeek>" + weekdays + "</DaysOfWeek><MonthsOfYear>" + months + "</MonthsOfYear></MonthlyDOWRecurrence></ScheduleDefinition>";
                    }
                }
                else if (checkMonths1.Checked)
                {
                    chkMonthsRange = monthRange.Value;

                    setTime = timeSchedule.Value;
                    startScheduleDate = startSchedule.Value;
                    if (checkSchedule.Checked)
                    {
                        stopScheduleDate = stopSchedule.Value;
                        checkXml = "<ScheduleDefinition><StartDateTime>" + startScheduleDate + "T" + setTime + "</StartDateTime><EndDate>" + stopScheduleDate + "</EndDate><MonthlyRecurrence><Days>" + chkMonthsRange + "</Days><MonthsOfYear>" + months + "</MonthsOfYear></MonthlyRecurrence></ScheduleDefinition>";
                    }
                    else
                    {
                        checkXml = "<ScheduleDefinition><StartDateTime>" + startScheduleDate + "T" + setTime + "</StartDateTime><MonthlyRecurrence><Days>" + chkMonthsRange + "</Days><MonthsOfYear>" + months + "</MonthsOfYear></MonthlyRecurrence></ScheduleDefinition>";
                    }
                }
            }

            ReportingWebService.ReportingService2010 rs = new ReportingService2010();
            rs.Credentials = new CustomReportCredentials(ConfigurationManager.AppSettings["UserName"].ToString(), ConfigurationManager.AppSettings["Password"].ToString(), ConfigurationManager.AppSettings["ServerDomain"].ToString()).NetworkCredentials;

            string report = "/Reporting.GreenYourBills/rptCaseSummary";
            string desc = "Case Summary Report";

            string eventType = "TimedSubscription";
            string scheduleXml = @"" + checkXml;

            ParameterValue[] extensionParams = new ParameterValue[8];

            extensionParams[0] = new ParameterValue();
            extensionParams[0].Name = "TO";
            extensionParams[0].Value = deliveryTo.Value.ToString();

            extensionParams[1] = new ParameterValue();
            extensionParams[1].Name = "ReplyTo";
            extensionParams[1].Value = "ggsupport@greenyourbills.com";

            extensionParams[2] = new ParameterValue();
            extensionParams[2].Name = "IncludeReport";
            extensionParams[2].Value = chkIncludeReport.Checked.ToString();

            extensionParams[3] = new ParameterValue();
            extensionParams[3].Name = "RenderFormat";
            extensionParams[3].Value = ddlDelivery.Value;

            extensionParams[4] = new ParameterValue();
            extensionParams[4].Name = "Subject";
            extensionParams[4].Value = deliverySubject.Value;

            extensionParams[5] = new ParameterValue();
            extensionParams[5].Name = "IncludeLink";
            extensionParams[5].Value = chkIncludeLink.Checked.ToString();

            extensionParams[6] = new ParameterValue();
            extensionParams[6].Name = "Priority";
            extensionParams[6].Value = "NORMAL";


            int k = 0;
            ParameterValue[] parameters = new ParameterValue[scheduleParam.Count];
            List<BusinessObject.ReportParameterschedule> lstParameteSchedule = new List<BusinessObject.ReportParameterschedule>();

            foreach (ReportParameter param in scheduleParam)
            {
                parameters[k] = new ParameterValue();
                parameters[k].Name = param.Name;
                parameters[k].Value = param.Values[0];

                k++;
            }
            lstParameteSchedule = (List<BusinessObject.ReportParameterschedule>)scheduleParam1[1];
            byte[] parameterValueAsByte = Utility.ObjectToByteArray(lstParameteSchedule);
            string matchData = scheduleXml;
            ExtensionSettings extSettings = new ExtensionSettings();
            extSettings.ParameterValues = extensionParams;
            extSettings.Extension = "Report Server Email";

            try
            {
                string subscriptionID = rs.CreateSubscription(report, extSettings, desc, eventType, matchData, parameters);
                if (subscriptionID != null)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "ShowSuccessMessage('Subscription Created Successfully','test');", true);
                    ReportData.SaveSubscription(ReportId, parameterValueAsByte, desc, subscriptionID, SubsID, Session["LoginID"].ToString(), ScheduleType, WeekDay.Checked, NoOfDays.Checked, noOfDays,
                        noOfWeeks, WeeksList, MonthsList, checkMonths.Checked, chkMonthsWeek, checkMonths1.Checked, chkMonthsRange, setTime,
                        startScheduleDate, checkSchedule.Checked, stopScheduleDate, deliveryTo.Value.ToString(), deliverySubject.Value.ToString(),
                        chkIncludeReport.Checked, chkIncludeLink.Checked, ddlDelivery.Value);
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "ShowErrorMessage('Error Occured','test');", true);
                }

            }

            catch (SoapException exp)
            {
                throw exp;
            }
        }
    }
}
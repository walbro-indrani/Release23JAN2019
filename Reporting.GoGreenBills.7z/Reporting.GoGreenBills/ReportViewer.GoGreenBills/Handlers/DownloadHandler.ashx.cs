﻿using ReportViewer.GoGreenBills.BusinessObject;
using ReportViewer.GoGreenBills.DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace ReportViewer.GoGreenBills.Handlers
{
    /// <summary>
    /// Summary description for Handler1
    /// </summary>
    public class ReportData : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            string RequestFrom = "ChartRevenue";

            if (context.Request["RequestFrom"] != null)
                RequestFrom = context.Request["RequestFrom"];

            switch (RequestFrom)
            {
                case ("ChartRevenue") :
                    ChartRevenueData(context);
                    break;
                case ("VisitSummary"):
                    VisitSummaryData(context);
                    break;
            }

            //context.Response.ContentType = "text/plain";
            //context.Response.Write("Hello World");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        private void ChartRevenueData(HttpContext context)
        {
            string GroupData = context.Request["GroupData"];
            string reportType = context.Request["reportType"];
            string subReportType = context.Request["subReportType"];
            string companyId = context.Request["companyId"];
            string speciality = context.Request["speciality"] == "" ? null : context.Request["speciality"];
            string insuranceName = context.Request["insuranceName"] == "" ? null : context.Request["insuranceName"];
            string provider = context.Request["provider"] == "" ? null : context.Request["provider"];
            string doctorName = context.Request["doctorName"] == "" ? null : context.Request["doctorName"];
            string providerLocation = context.Request["providerLocation"] == "" ? null : context.Request["providerLocation"];
            string interval = context.Request["interval"] == "" ? null : context.Request["interval"];
            string period = context.Request["period"] == "" ? null : context.Request["period"];
            string caseType = context.Request["caseType"] == "" ? null : context.Request["caseType"];
            string fromDate = context.Request["fromDate"] == "" ? null : context.Request["fromDate"];
            string toDate = context.Request["toDate"] == "" ? null : context.Request["toDate"];

            string procedure = "";
            if (reportType == "Billing Report")
            {
                if ((subReportType == "Billing Report" || subReportType == "Pending Receivable Trending Reports") && GroupData == "speciality")
                    procedure = DataDownloadConstants.specRevenueData;
                else if ((subReportType == "Billing Report" || subReportType == "Pending Receivable Trending Reports") && GroupData == "Provider")
                    procedure = DataDownloadConstants.provRevenueData;
                else if ((subReportType == "Billing Report" || subReportType == "Pending Receivable Trending Reports") && GroupData == "Insurance")
                    procedure = DataDownloadConstants.insurRevenueData;
                else
                    return;
            }

            var dtDATA = DashboardReport.GetReportDATA(companyId, speciality, insuranceName, provider, doctorName, providerLocation, caseType, interval, period, fromDate, toDate, procedure);

            var filename = subReportType.Replace(" ", "") + "By" + GroupData + ".xls";

            DownloadToExcel(dtDATA, filename, context);
        }

        private void VisitSummaryData(HttpContext context)
        {
            string companyId = context.Request["companyId"];
            string speciality = context.Request["speciality"] == "" ? null : context.Request["speciality"];
            string doctorName = context.Request["doctorName"] == "" ? null : context.Request["doctorName"];
            string providerLocation = context.Request["providerLocation"] == "" ? null : context.Request["providerLocation"];
            string fromDate = context.Request["fromDate"] == "" ? null : context.Request["fromDate"];
            string toDate = context.Request["toDate"] == "" ? null : context.Request["toDate"];

            string procedure = DataDownloadConstants.vistiSummaryData;
            

            var dtDATA = DashboardReport.GetVisitSummaryDATA(companyId, speciality, doctorName, providerLocation, fromDate, toDate, procedure);

            var filename = "VisitSummaryData.xls";

            DownloadToExcel(dtDATA, filename, context);
        }

        private void DownloadToExcel(DataTable dt, string filename, HttpContext context)
        {
            // context.Response.ClearContent();
            context.Response.Buffer = true;
            context.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", filename));
            //context.Response.ContentType = "application/ms-excel"; 
            context.Response.ContentType = "application/vnd.ms-excel";

            string str = string.Empty;
            if (dt != null)
            {
                foreach (DataColumn dtcol in dt.Columns)
                {
                    context.Response.Write(str + dtcol.ColumnName);
                    str = "\t";
                }
                context.Response.Write("\n");
                foreach (DataRow dr in dt.Rows)
                {
                    str = "";
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        context.Response.Write(str + Convert.ToString(dr[j]));
                        str = "\t";
                    }
                    context.Response.Write("\n");
                }
            }
            context.Response.End();
        }
    }
}
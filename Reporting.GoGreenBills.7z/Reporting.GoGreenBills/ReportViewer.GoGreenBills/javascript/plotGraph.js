﻿
function plotLineGraph(chartData, title, reportId) {
        chart = new AmCharts.AmSerialChart();
        chart.dataProvider = chartData; //chartData;
        chart.titles = [{ "text": title }];
        chart.marginLeft = 10;
        chart.categoryField = "TimePeriod"; //Object.keys(chartData[0])[0];
        chart.addLabel = reportId;
        chart.depth3D = 1;
        chart.angle = 30;
        if (reportId >= "0" && reportId <= "3") {
            chart.addListener("clickGraphItem", handleClick);
        }

        // category
        var categoryAxis = chart.categoryAxis;
        categoryAxis.dashLength = 3;
        categoryAxis.minorGridEnabled = true;
        categoryAxis.minorGridAlpha = 0.1;

        // value
        var valueAxis = new AmCharts.ValueAxis();
        valueAxis.axisAlpha = 0;
        valueAxis.gridAlpha = 0;
        valueAxis.dashLength = 3;
        chart.addValueAxis(valueAxis);

        var len = Object.keys(chartData[0]).length;
        for (var i = 1; i < Object.keys(chartData[0]).length; i++) {
            if (Object.keys(chartData[0])[i].includes("+")) { len = i; break; }
        }

        // GRAPH -- Funded Amount
    for (var i = 0; i < len; i++) {

        if (Object.keys(chartData[0])[i].includes("+")) { break; }

        if (Object.keys(chartData[0])[i] != "TimePeriod" && Object.keys(chartData[0])[i] != "BillCount") {
            graph = new AmCharts.AmGraph();
            graph.title = Object.keys(chartData[0])[i];
            graph.type = "line";
            graph.lineColor = color[i];
            graph.negativeLineColor = "#637bb6"; // this line makes the graph to change color when it drops below 0
            graph.bullet = "round";
            graph.bulletSize = 8;
            graph.bulletBorderColor = "#FFFFFF";
            graph.bulletBorderAlpha = 1;
            graph.bulletBorderThickness = 2;
            graph.lineThickness = 2;
            graph.lineAlpha = 1;
            graph.fillAlphas = 0;
            graph.valueAxis = valueAxis;
            graph.startDuration = 1;
            graph.valueField = Object.keys(chartData[0])[i];
            if (reportId >= 3 || (reportId >= 1.1 && reportId <= 1.3)) {
                graph.balloonText = Object.keys(chartData[0])[i] + ", count = [[" + Object.keys(chartData[0])[i] + "]]";
            }
            else {
                var GroupedItemsCount = len - 1;
                graph.balloonText = Object.keys(chartData[0])[i] + "<br/> Amount : $[[" + Object.keys(chartData[0])[i] + "]]" + "<br> Paid Amount : $[[" + Object.keys(chartData[0])[i + GroupedItemsCount] + "]]" + "<br> OutStanding Amount : $[[" + Object.keys(chartData[0])[i + (GroupedItemsCount * 2)] + "]]" + "<br> WrittenOff Amount : $[[" + Object.keys(chartData[0])[i + (GroupedItemsCount * 3)] + "]]" + "<br> Total Bills Count : [[" + Object.keys(chartData[0])[i + (GroupedItemsCount * 4)] + "]]";

            }
            graph.balloonFunction = numberFormatter;
            chart.addGraph(graph);
            // CURSOR
            var chartCursor = new AmCharts.ChartCursor();
            chartCursor.cursorAlpha = 1;
            chartCursor.cursorPosition = "mouse";
            chartCursor.oneBalloonOnly = true;
            chartCursor.balloonPointerOrientation = "center";
            chart.addChartCursor(chartCursor);
            chart.creditsPosition = "bottom-right";
        }
    }
        // LEGEND
        if (reportId > 3) {
            categoryAxis.labelRotation = 15;
        }
        if (reportId == 3) {
            categoryAxis.labelRotation = 20;
            chart.marginLeft = 130;
        }
        else {
            var legend = new AmCharts.AmLegend();
            legend.borderAlpha = 0.2;
            legend.useGraphSettings = true;
            legend.markerSize = 10;
            legend.horizontalGap = 10;
            legend.position = "right";
            legend.labelWidth = 130;
            legend.valueWidth = 0;
            chart.addLegend(legend);
        }
        chart.export = {
            enabled: true,
            position: "bottom-right"
        }
        chart.initHC = false;
        chart.validateNow();
        return chart;
}

function plotBarGraph(chartData, title, reportType) {
    chart = new AmCharts.AmSerialChart();
    chart.dataProvider = chartData; //chartData;
    chart.titles = [{ "text": title }];
    chart.marginLeft = 10;
    chart.categoryField = "TimePeriod"; //Object.keys(chartData[0])[0];
    chart.addLabel = "Demo";
    chart.depth3D = 1;
    chart.angle = 30;
    chart.startDuration = 0;

    // category
    var categoryAxis = chart.categoryAxis;
    categoryAxis.dashLength = 3;
    categoryAxis.minorGridEnabled = true;
    categoryAxis.minorGridAlpha = 0.1;

    // value
    var valueAxis = new AmCharts.ValueAxis();
    valueAxis.axisAlpha = 0;
    valueAxis.stackType = "regular";
    valueAxis.gridAlpha = 0;
    valueAxis.dashLength = 3;
    chart.addValueAxis(valueAxis);

    // GRAPH -- Funded Amount

    var len = Object.keys(chartData[0]).length;
    for (var i = 1; i < Object.keys(chartData[0]).length; i++) {
        if (Object.keys(chartData[0])[i].includes("+")) { len = i; break; }
    }

    for (var i = 0; i < len; i++) {

        if (Object.keys(chartData[0])[i].includes("+")) { break; }

        if (Object.keys(chartData[0])[i] != "TimePeriod") {
            graph = new AmCharts.AmGraph();
            graph.title = Object.keys(chartData[0])[i];
            graph.type = "column";
            graph.lineColor = color[i];
            graph.negativeLineColor = "#637bb6"; // this line makes the graph to change color when it drops below 0
            graph.lineThickness = 2;
            graph.lineAlpha = 0.3;
            graph.fillAlphas = 1;
            graph.valueField = Object.keys(chartData[0])[i];
            graph.valueAxis = valueAxis;
            if (Object.keys(chartData[0]).length <= 2) {
                if (reportType == "Denial Reports") {
                    categoryAxis.labelRotation = 25;
                    graph.balloonText = " Count : [[" + Object.keys(chartData[0])[i] + "]]";
                }
                else graph.balloonText = " Amount : $[[" + Object.keys(chartData[0])[i] + "]]";
            }
            else {
                graph.balloonText = Object.keys(chartData[0])[i] + " Amount : $[[" + Object.keys(chartData[0])[i] + "]]";
            }
            graph.balloonFunction = numberFormatter;
            chart.addGraph(graph);
        }
    }
    // CURSOR
    var chartCursor = new AmCharts.ChartCursor();
    chartCursor.cursorAlpha = 1;
    chartCursor.cursorPosition = "mouse";
    chartCursor.oneBalloonOnly = true;
    chartCursor.balloonPointerOrientation = "center";
    //chartCursor.categoryBalloonDateFormat = "YYYY";
    chart.addChartCursor(chartCursor);
    chart.creditsPosition = "bottom-right";

    // LEGEND
    var legend = new AmCharts.AmLegend();
    if (Object.keys(chartData[0]).length <= 2) {
        legend.switchable = false;
        if (reportType == "Denial Reports") {
            legend.labelText = "Count";
        }
    }
    legend.borderAlpha = 0.2;
    legend.useGraphSettings = true;
    legend.markerSize = 10;
    legend.horizontalGap = 10;
    legend.position = "right";
    legend.labelWidth = 130;
    legend.valueWidth = 0;
    chart.addLegend(legend);

    chart.numberFormatter = {
        precision: 1, decimalSeparator: '.', thousandsSeparator: ','
    }
    chart.export = {
        enabled: true,
        position: "bottom-right"
    }
    chart.initHC = false;
    chart.validateNow();
    return chart;
}

function plotPieGraph(chartData, title, ballonText) {
    // PIE CHART
    chart = new AmCharts.AmPieChart();
    chart.titles = [{ "text": title }];
    chart.dataProvider = chartData;
    chart.titleField = Object.keys(chartData[0])[0];    //"year"
    chart.valueField = Object.keys(chartData[0])[1];    //"Revenue"
    chart.outlineColor = "#FFFFFF";
    chart.outlineThickness = 2;
    chart.innerRadius = 20;
    chart.sequencedAnimation = true;
    chart.startEffect = "elastic";
    chart.pullOutEffect = "elastic";
    chart.startDuration = 1;
    chart.depth3D = 10;
    chart.angle = 15;
    // for percent [[percents]]%
    chart.balloonText = "[[" + Object.keys(chartData[0])[0] + "]], " + ballonText + "[[" + Object.keys(chartData[0])[1] + "]] ([[percents]]%)";
    chart.balloonFunction = ballonNumberFormatter;
    chart.marginTop = 50;
    chart.labelsEnabled = false;
    chart.ignoreAxisWidth = true;
    chart.autoWrap = true;
    // LEGEND
    var legend = new AmCharts.AmLegend();
    legend.borderAlpha = 0.2;
    legend.horizontalGap = 10;
    legend.position = "right";
    //legend.equalWidths = true;
    legend.valueText = "[[" + Object.keys(chartData[0])[1] + "]]";
    legend.labelWidth = 150;
    legend.valueWidth = 0;
    chart.addLegend(legend);
    chart.validateNow();
    chart.export = {
        enabled: true,
        position: "bottom-right"
    }
    chart.initHC = false;
    chart.validateNow();
    return chart;
}

function plotColumnGraph(chartData, title, reportId) {
    chart = new AmCharts.AmSerialChart();
    chart.dataProvider = chartData; //chartData;
    chart.titles = [{ "text": title }];
    chart.marginLeft = 10;
    chart.categoryField = "TimePeriod"; // Object.keys(chartData[0])[0];
    chart.addLabel = "Demo";
    chart.depth3D = 1;
    chart.angle = 30;
    chart.startDuration = 0;
    if (reportId >= "0" && reportId <= "3" && chart.titles[0].text != "Monthly Total Billing Report for Last Year") {
        chart.addListener("clickGraphItem", handleClick);
    }

    // category
    var categoryAxis = chart.categoryAxis;
    categoryAxis.dashLength = 3;
    categoryAxis.minorGridEnabled = true;
    categoryAxis.minorGridAlpha = 0.1;

    // value
    var valueAxis = new AmCharts.ValueAxis();
    valueAxis.axisAlpha = 0;
    valueAxis.gridAlpha = 0;
    valueAxis.dashLength = 3;
    chart.addValueAxis(valueAxis);

    // GRAPH -- Funded Amount
    var len = Object.keys(chartData[0]).length;
    for (var i = 1; i < Object.keys(chartData[0]).length; i++) {
        if (Object.keys(chartData[0])[i].includes("+")) { len = i; break; }
    }

    for (var i = 1; i < len; i++) {
        if (Object.keys(chartData[0])[i].includes("+")) { break; }
        
        if (Object.keys(chartData[0])[i] != "TimePeriod") {
            graph = new AmCharts.AmGraph();
            graph.title = Object.keys(chartData[0])[i];
            graph.type = "column";
            graph.lineColor = color[i - 1];
            graph.negativeLineColor = "#637bb6"; // this line makes the graph to change color when it drops below 0
            graph.lineThickness = 2;
            graph.lineAlpha = 0.3;
            graph.fillAlphas = 1;
            graph.valueField = Object.keys(chartData[0])[i];

            if ((Object.keys(chartData[0])[2]) == "PaidAmount") {
                graph.balloonText = " Amount : $[[" + Object.keys(chartData[0])[1] + "]]" + "<br> Paid Amount : $[[" + Object.keys(chartData[0])[2] + "]]" + "<br> OutStanding Amount : $[[" + Object.keys(chartData[0])[3] + "]]" + "<br> WrittenOff Amount : $[[" + Object.keys(chartData[0])[4] + "]]" + "<br> Total Bills Count : [[" + Object.keys(chartData[0])[5].toString() + "]]";

                graph.startDuration = 1;
                graph.balloonFunction = numberFormatter;
                chart.addGraph(graph);
                break;
            }
                //else if (Object.keys(chartData[0]).length <= 2 || reportId >= 4) {
                //    if (reportId >= 0 && reportId <= 0.3) {
                //        graph.balloonText = "Amount = $[[" + Object.keys(chartData[0])[1] + "]]";
                //        //graph.balloonText = Object.keys(chartData[0])[i] + " : [[" + Object.keys(chartData[0])[i] + "]]";
                //    }
                //    else if (reportId >= 3.1) {
                //        graph.balloonText = "Count = [[" + Object.keys(chartData[0])[i] + "]]";
                //    }
                //    else if (reportId >= 1.1 && reportId <= 1.3) {
                //        graph.balloonText = "Collected Amount = $[[" + Object.keys(chartData[0])[1] + "]]";
                //    }
                //    else if (reportId >= 2.1 && reportId <= 2.3) {
                //        graph.balloonText = "OutStanding Amount = $[[" + Object.keys(chartData[0])[1] + "]]";
                //    }
                //}
            else {
                if (reportId >= 0 && reportId <= 0.3) {
                    var GroupedItemsCount = len - 1;
                    graph.balloonText = Object.keys(chartData[0])[i] + "<br/> Amount : $[[" + Object.keys(chartData[0])[i] + "]]" + "<br> Paid Amount : $[[" + Object.keys(chartData[0])[i + GroupedItemsCount] + "]]" + "<br> OutStanding Amount : $[[" + Object.keys(chartData[0])[i + (GroupedItemsCount * 2)] + "]]" + "<br> WrittenOff Amount : $[[" + Object.keys(chartData[0])[i + (GroupedItemsCount * 3)] + "]]" + "<br> Total Bills Count : [[" + Object.keys(chartData[0])[i + (GroupedItemsCount * 4)] + "]]";
                    //graph.balloonText = Object.keys(chartData[0])[i] + " : [[" + Object.keys(chartData[0])[i] + "]]";
                }
                else if (reportId >= 3.1) {
                    graph.balloonText = Object.keys(chartData[0])[i] + "<br/>Count : [[" + Object.keys(chartData[0])[i] + "]]";
                }
                else if (reportId >= 1.1 && reportId <= 1.3) {
                    graph.balloonText = Object.keys(chartData[0])[i] + "<br/>Collected Amount : $[[" + Object.keys(chartData[0])[i] + "]]";
                }
                else if (reportId >= 2.1 && reportId <= 2.3) {
                    var GroupedItemsCount = len - 1;
                    graph.balloonText = Object.keys(chartData[0])[i] + "<br/> OutStanding Amount : $[[" + Object.keys(chartData[0])[i] + "]]" + "<br> Paid Amount : $[[" + Object.keys(chartData[0])[i + GroupedItemsCount] + "]]" + "<br> Bill Amount : $[[" + Object.keys(chartData[0])[i + (GroupedItemsCount * 2)] + "]]" + "<br> WrittenOff Amount : $[[" + Object.keys(chartData[0])[i + (GroupedItemsCount * 3)] + "]]" + "<br> Total Bills Count : [[" + Object.keys(chartData[0])[i + (GroupedItemsCount * 4)] + "]]";
                }
                //graph.balloonText = Object.keys(chartData[0])[i] + ": $[[" + Object.keys(chartData[0])[i] + "]]";
            }

            graph.startDuration = 1;
            if (reportId == 3) {
                graph.balloonFunction = percentFormatter;
            }
            else graph.balloonFunction = numberFormatter;
            chart.addGraph(graph);
        }
    }
    // CURSOR
    var chartCursor = new AmCharts.ChartCursor();
    chartCursor.cursorAlpha = 1;
    chartCursor.cursorPosition = "mouse";
    chartCursor.oneBalloonOnly = true;
    chartCursor.balloonPointerOrientation = "center";
    chart.addChartCursor(chartCursor);
    chart.creditsPosition = "bottom-right";

    // LEGEND
    var legend = new AmCharts.AmLegend();
    if (reportId == 3) {
        categoryAxis.labelRotation = 20;
        chart.marginLeft = 130;
    }
    if (reportId > 4) {
        categoryAxis.labelRotation = 15;
        legend.borderAlpha = 0.2;
        legend.useGraphSettings = true;
        legend.markerSize = 10;
        legend.horizontalGap = 10;
        legend.position = "right";
        legend.labelWidth = 130;
        legend.valueWidth = 0;
        chart.addLegend(legend);
    }
    else {
        if (Object.keys(chartData[0]).length <= 2) {
            legend.switchable = false;
        }
        legend.borderAlpha = 0.2;
        legend.useGraphSettings = true;
        legend.markerSize = 10;
        legend.horizontalGap = 10;
        legend.position = "right";
        legend.labelWidth = 130;
        legend.valueWidth = 0;
        chart.addLegend(legend);
    }
    chart.export = {
        enabled: true,
        position: "bottom-right"
    }
    chart.initHC = false;
    chart.validateNow();
    return chart;
}

function plotStockChart(chartData, title, reportId) {

    var chart = new AmCharts.AmStockChart();
    var Amount = [2];
    var BillCount;
        Amount[0] = JSON.parse(JSON.stringify(chartData));
        Amount[1] = JSON.parse(JSON.stringify(chartData));
        for (var i = 0; i < chartData.length; i++) {
            for (var j = 0; j < Object.keys(chartData[0]).length; j++) {
                if (j != 0) {
                    var a = Object.keys(chartData[i])[j];
                    if (Object.values(chartData[i])[j] != null)
                        (Amount[0][i])[a] = Object.values(chartData[i])[j].split(",")[0];
                }
            }
        }
        for (var i = 0; i < chartData.length; i++) {
            for (var j = 0; j < Object.keys(chartData[0]).length; j++) {
                if (j != 0) {
                    var a = Object.keys(chartData[i])[j];
                    if (Object.values(chartData[i])[j] != null)
                        (Amount[1][i])[a] = Object.values(chartData[i])[j].split(",")[1];
                }
            }
        
        }
    //var dataSet1 = new AmCharts.DataSet();
    //dataSet1.dataProvider = Amount;
    //dataSet1.categoryField = "TimePeriod";
    //dataSet1.fieldMappings = [{ fromField: "TimePeriod", toField: "TimePeriod" }];
    //chart.dataSets = dataSet1;
    
    //var stockPanel = new AmCharts.StockPanel();
    //stockPanel.title = title;
    //stockPanel.dataSet = dataSet1;

    //var valueAxis1 = new AmCharts.ValueAxis();
    //stockPanel.addValueAxis(valueAxis1);

    //var valueAxis2 = new AmCharts.ValueAxis();
    //valueAxis2.position = "right";
    //stockPanel.addValueAxis(valueAxis2);

    //var panelsSettings = new AmCharts.PanelsSettings();
    //panelsSettings.startDuration = 1;
    //chart.panelsSettings = panelsSettings;

    ////for(var i=0; i< Object.keys(chartData[0]).length;i++)
    ////{
    ////    if(Object.keys(chartData[0])[i] != "TimePeriod")
    ////    {
    //        // graph #1
    //        var graph1 = new AmCharts.StockGraph();
    //        graph1.title = Object.keys(Amount[0][0])[1];
    //        graph1.valueField = Object.keys(Amount[0][0])[1];
    //        graph1.type = "Column";
    //        graph1.lineThickness = 3;
    //        graph1.lineColor = "#00cc00";
    //        graph1.ValueAxis = valueAxis1;
    //        graph1.useDataSetColors = false;
    //        stockPanel.addStockGraph(graph1);

    //        // graph #2
    //        var graph2 = new AmCharts.StockGraph();
    //        graph2.title = Object.keys(Amount[1][0])[1];
    //        graph2.valueField = Object.keys(Amount[1][0])[1];
    //        graph2.type = "line";
    //        graph2.showBalloon = false;
    //        graph2.fillAlphas = 0.5;
    //        graph2.valueAxis = valueAxis2;
    //        stockPanel.addStockGraph(graph2);
    ////    }
        
    ////}
    //chart.panels = [stockPanel];

        var chart = new AmCharts.AmStockChart();
        chart.pathToImages = "amcharts/images/";

        var dataSet = new AmCharts.DataSet();
        dataSet.dataProvider = Amount[0][0];
        dataSet.fieldMappings = [{ fromField: "TimePeriod", toField: "Others" }];
        dataSet.categoryField = "TimePeriod";
        chart.dataSets = [dataSet];

        var stockPanel = new AmCharts.StockPanel();
        chart.panels = [stockPanel];

        var legend = new AmCharts.StockLegend();
        stockPanel.stockLegend = legend;

        var panelsSettings = new AmCharts.PanelsSettings();
        panelsSettings.startDuration = 1;
        chart.panelsSettings = panelsSettings;

        var graph = new AmCharts.StockGraph();
        graph.valueField = Object.keys(Amount[0][0])[1];
        graph.type = "column";
        graph.title = title;
        graph.fillAlphas = 1;
        stockPanel.addStockGraph(graph);

        var categoryAxesSettings = new AmCharts.CategoryAxesSettings();
        categoryAxesSettings.dashLength = 5;
        chart.categoryAxesSettings = categoryAxesSettings;

        var valueAxesSettings = new AmCharts.ValueAxesSettings();
        valueAxesSettings.dashLength = 5;
        chart.valueAxesSettings = valueAxesSettings;

        var chartScrollbarSettings = new AmCharts.ChartScrollbarSettings();
        chartScrollbarSettings.graph = graph;
        chartScrollbarSettings.graphType = "line";
        chart.chartScrollbarSettings = chartScrollbarSettings;

        var chartCursorSettings = new AmCharts.ChartCursorSettings();
        chartCursorSettings.valueBalloonsEnabled = true;
        chart.chartCursorSettings = chartCursorSettings;

    return chart;
}

function numberFormatter(item, graph) {
    var result = graph.balloonText;
    var decimalFormatter;
    if (chart.addLabel >= 4) {
        decimalFormatter = 0;
    }
    else decimalFormatter = 2;
    for (var key in item.dataContext) {
        if (item.dataContext.hasOwnProperty(key) && !isNaN(item.dataContext[key])) {
            var formatted = AmCharts.formatNumber(item.dataContext[key], {
                precision: chart.precision,
                decimalSeparator: chart.decimalSeparator,
                thousandsSeparator: chart.thousandsSeparator
            }, decimalFormatter);
            result = result.replace("[[" + key + "]]", formatted);
        }
    }
    return result;
};

function percentFormatter(item, graph) {
    var total = 0;
    for (var i = 0; i < chart.dataProvider.length; i++) {
        total += chart.dataProvider[i][item.graph.valueField];
    }
    return item.category + ": " + Math.round((item.values.value / total) * 1000) / 10 + "%" + "</br>" + "Count " + ": " + (item.values.value);
}

function ballonNumberFormatter(item, chart) {
    var result = chart;
    for (var key in item.dataContext) {
        if (item.dataContext.hasOwnProperty(key) && !isNaN(item.dataContext[key])) {
            var formatted = (item.dataContext[key]).formatMoney(0, '.', ',');
            result = result.replace(item.dataContext[key], formatted);
        }
    }
    return result;


};

Number.prototype.formatMoney = function (c, d, t) {
    var n = this,
        c = isNaN(c = Math.abs(c)) ? 2 : c,
        d = d == undefined ? "." : d,
        t = t == undefined ? "," : t,
        s = n < 0 ? "-" : "",
        i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
        j = (j = i.length) > 3 ? j % 3 : 0;
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};

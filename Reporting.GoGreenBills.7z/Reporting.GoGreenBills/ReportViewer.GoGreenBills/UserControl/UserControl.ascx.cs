﻿using ReportViewer.GoGreenBills.DataLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using Telerik.Web.UI;
using ReportViewer.GoGreenBills.BusinessObject;

namespace ReportViewer.GoGreenBills.UserControl
{
    public partial class UserControl : System.Web.UI.UserControl
    {
        private const int NUMBER_OF_PARAMETERS_PER_ROW = 4;
        ClsCommon ccls = new ClsCommon();

        protected void Page_Load(object sender, EventArgs e)
        {
            string value = Page.Items["ReportID"].ToString();

            byte[] subscriptionData = (byte[])Page.Items["SubscriptionParameter"];
            if(subscriptionData != null)
            {
                List<BusinessObject.ReportParameterschedule> lstParameteSchedule = new List<BusinessObject.ReportParameterschedule>();
                lstParameteSchedule = (List<BusinessObject.ReportParameterschedule>)Utility.ByteArrayToObject(subscriptionData);
                AddReportParameter(Convert.ToInt32(value), lstParameteSchedule);
            }
            else
            {
                AddReportParameter(Convert.ToInt32(value));

            }
        }
        public void AddReportParameter(int reportId)
        {
            string companyId = ((List<string>)(Session["Companies"])).Count > 0 ? ((List<string>)(Session["Companies"])).Aggregate((x, y) => x + "," + y) : "";

            List<ReportParameter> parameterList = ReportData.GetReportParameter(reportId);

            int paramCounter = 1;
            TableRow tr = new TableRow();
            foreach (ReportParameter param in parameterList)
            {               
                TableCell tc = new TableCell();

                if (param.ParameterTypeName != "CheckBox" && param.ParameterTypeName != "RadioButton")
                {
                    Label lbl = new Label();
                    lbl.Text = param.DisplayName + " : ";
                    tc.Controls.Add(lbl);
                }

                string controlName = (param.DisplayName + param.ParameterTypeID.ToString()).Replace(" ", "");

                #region parameter
                switch (param.ParameterTypeID)
                {

                    case 1:
                        TextBox tb = new TextBox();
                        tb.ID = controlName;
                        tb.CssClass = "form-control";
                        tc.Controls.Add(tb);
                        break;
                    case 2:
                        TextBox etb = new TextBox();
                        etb.ID = controlName;
                        etb.CssClass = "form-control";
                        tc.Controls.Add(etb);
                        AutoCompleteExtender ac = new AutoCompleteExtender();
                        ac.ContextKey = companyId;
                        ac.ID = "ac" + controlName;
                        ac.DelimiterCharacters = "";
                        ac.TargetControlID = controlName;
                        ac.ServiceMethod = param.DataSource;
                        ac.ServicePath = "../Services/PatientService.asmx";
                        ac.UseContextKey = true;
                        ac.EnableCaching = true;
                        ac.MinimumPrefixLength = 1;
                        ac.CompletionInterval = 500;
                        tc.Controls.Add(ac);
                        break;
                    case 3:
                        DropDownList ddl = new DropDownList();
                        ddl.ID = controlName;
                        var data = ReportData.GetKeyValueData(param.DataSource, companyId); //param.DataSource
                        ddl.DataSource = data;
                        ddl.DataTextField = "Value";
                        ddl.DataValueField = "Key";
                        ddl.DataBind();
                        if(param.DataSource != "GroupBy" && param.DataSource != "ReportType")
                        {
                            ddl.Items.Insert(0, new ListItem("--" + param.DisplayName + "--", "NA"));
                        }
                        ddl.SelectedIndex = 0;
                        ddl.CssClass = "form-control";
                        tc.Controls.Add(ddl);
                        break;
                    case 4:
                        RadComboBox rbddl = new RadComboBox();
                        rbddl.EmptyMessage = "- Select -";
                        rbddl.EnableCheckAllItemsCheckBox = true;
                        rbddl.CheckBoxes = true;
                        rbddl.RenderMode = RenderMode.Lightweight;
                        rbddl.Style.Add("width", "100%");
                        rbddl.ID = controlName;
                        var rbdata = ReportData.GetKeyValueData(param.DataSource, companyId); //param.DataSource
                        rbddl.Filter = RadComboBoxFilter.Contains;
                        rbddl.DataSource = rbdata;
                        rbddl.DataTextField = "Value";
                        rbddl.DataValueField = "Key";
                        rbddl.DataBind();
                        tc.Controls.Add(rbddl);
                        break;
                    case 5:
                        CheckBox cb = new CheckBox();
                        cb.Text = param.DisplayName;
                        cb.ID = controlName;
                        cb.CssClass = "chk1 checkbox1 checkbox-inline center-block innerStyleChk";

                        tc.Controls.Add(cb);
                        break;
                    case 6:
                        break;
                    case 7:
                        RadioButton rb = new RadioButton();
                        rb.Text = param.DisplayName;
                        rb.ID = controlName;
                        rb.CssClass = "form-control";
                        tc.Controls.Add(rb);
                        break;
                    case 8:
                        System.Web.UI.HtmlControls.HtmlGenericControl calenderDiv = new System.Web.UI.HtmlControls.HtmlGenericControl();
                        System.Web.UI.HtmlControls.HtmlGenericControl innercalenderDiv = new System.Web.UI.HtmlControls.HtmlGenericControl();
                        innercalenderDiv.ID = "div" + controlName;
                        var sb = new System.Text.StringBuilder();

                        sb.Append("<div class='input-append date form_datetime' >");
                        sb.Append("<div class='inner-addon left-addon' >");
                        sb.Append("<i class='glyphicon glyphicon-calendar'></i>");
                        sb.Append("<input type='text' name='ctl00$ContentPlaceHolder1$ctl03$" + controlName + "' class='form-control' id='" + controlName + "' maxlength='10' onChange='checkValue(this);' />");
                        sb.Append("</div>");
                        sb.Append("<span class='add-on' > <i class='icon-th' > </i> </span>");
                        sb.Append("</div>");
                        innercalenderDiv.InnerHtml = sb.ToString();
                        tc.Controls.Add(innercalenderDiv);
                        HiddenField hdn = new HiddenField();
                        hdn.ID = "hdn" + controlName;
                        tc.Controls.Add(hdn);
                        break;
                    case 9:
                        ListBox lstBox = new ListBox();
                        lstBox.ID = controlName;
                        var LstData = ReportData.GetKeyValueData(param.DataSource, companyId); 
                        lstBox.DataSource = LstData;
                        lstBox.DataTextField = "Value";
                        lstBox.DataValueField = "Key";
                        lstBox.DataBind();
                        if (param.DataSource != "GroupBy" && param.DataSource != "ReportType" && param.DataSource != "GroupByForVisit")
                        {
                            lstBox.Items.Insert(0, new ListItem("--" + param.DisplayName + "--", "NA"));
                        }
                        lstBox.SelectedIndex = 0;
                        lstBox.CssClass = "form-control";

                        HiddenField hdnList = new HiddenField();
                        hdnList.ID = "hdn" + controlName;

                        foreach (var item in LstData)
                            if(hdnList.Value.Equals(string.Empty))
                                hdnList.Value += item.Key;
                            else
                                hdnList.Value += ","+item.Key;
                        lstBox.Attributes.Add("onkeydown", "getKeyAndMove(this,'" + hdnList.ClientID + "', event);");
                        tc.Controls.Add(lstBox);

                        tc.Controls.Add(hdnList);
                       
                        break;
                    case 10:

                        System.Web.UI.HtmlControls.HtmlGenericControl LstDiv = new System.Web.UI.HtmlControls.HtmlGenericControl();
                        LstDiv.Attributes.Add("Style", "demo-container size-narrow");

                        System.Web.UI.HtmlControls.HtmlGenericControl LstDivWrapper = new System.Web.UI.HtmlControls.HtmlGenericControl();
                        LstDivWrapper.Attributes.Add("Style", "wrapper");

                        RadListBox rblstSource = new RadListBox();

                        rblstSource.ID = controlName+"Source";
                        var rblstData = ReportData.GetKeyValueData(param.DataSource, companyId); //param.DataSource
                        rblstSource.DataSource = rblstData;
                        rblstSource.DataTextField = "Value";
                        rblstSource.DataValueField = "Key";
                        rblstSource.DataBind();
                        rblstSource.AllowTransfer = true;
                        rblstSource.TransferToID = controlName;
                        rblstSource.RenderMode = RenderMode.Lightweight;
                        rblstSource.Height = Unit.Pixel(200);
                        rblstSource.Width = Unit.Pixel(230);

                        RadListBox rdlstTarget = new RadListBox();
                        rdlstTarget.RenderMode = RenderMode.Lightweight;
                        rdlstTarget.Height = Unit.Pixel(200);
                        rdlstTarget.Width = Unit.Pixel(200);
                        rdlstTarget.ID = controlName;

                        LstDivWrapper.Controls.Add(rblstSource);
                        LstDivWrapper.Controls.Add(rdlstTarget);

                        LstDiv.Controls.Add(LstDivWrapper);
                        tc.ColumnSpan = 3;

                        tc.Controls.Add(LstDiv);
                        
                        break;

                    default:
                        break;
                }
                #endregion
                if(param.DisplayName == "Columns To Be Shown")
                {
                    tblnew.Controls.Add(tr);
                    tr = new TableRow();
                    tc.ColumnSpan = 4;
                    tc.Style.Add("padding","1% 38% 0% 38%");
                    tr.Controls.Add(tc);

                }
                else
                {
                    tr.Controls.Add(tc);
                }
                if (paramCounter % NUMBER_OF_PARAMETERS_PER_ROW == 0 || paramCounter == parameterList.Count)
                {
                    tblnew.Controls.Add(tr);
                    tr = new TableRow();
                }
                paramCounter++;
            }
        }

        public void AddReportParameter(int reportId, List<ReportParameterschedule> lstParameteSchedule)
         {
            string companyId = ((List<string>)(Session["Companies"])).Count > 0 ? ((List<string>)(Session["Companies"])).Aggregate((x, y) => x + "," + y) : "";

            List<ReportParameter> parameterList = ReportData.GetReportParameter(reportId);

            int paramCounter = 1;
            TableRow tr = new TableRow();
            foreach (ReportParameter param in parameterList)
            {
                TableCell tc = new TableCell();

                if (param.ParameterTypeName != "CheckBox" && param.ParameterTypeName != "RadioButton")
                {
                    Label lbl = new Label();
                    lbl.Text = param.DisplayName + " : ";
                    tc.Controls.Add(lbl);
                }

                string controlName = (param.DisplayName + param.ParameterTypeID.ToString()).Replace(" ", "");

                #region parameter
                switch (param.ParameterTypeID)
                {

                    case 1:
                        TextBox tb = new TextBox();
                        foreach(var paramName in lstParameteSchedule)
                        {
                            if(paramName.ParameterName == param.DisplayName.Replace(" ", ""))
                            {
                                tb.ID = controlName;
                                tb.Text = paramName.Value;
                                tb.CssClass = "form-control";
                                tc.Controls.Add(tb);
                                lstParameteSchedule.Remove(paramName);
                                break;
                            }
                        }
                        break;
                    case 2:
                        TextBox etb = new TextBox();
                        foreach (var paramName in lstParameteSchedule)
                        {
                            if (paramName.ParameterName == param.DisplayName.Replace(" ", ""))
                            {
                                etb.ID = controlName;
                                etb.Text = paramName.Value;
                                etb.CssClass = "form-control";
                                tc.Controls.Add(etb);
                                AutoCompleteExtender ac = new AutoCompleteExtender();
                                ac.ContextKey = companyId;
                                ac.ID = "ac" + controlName;
                                ac.DelimiterCharacters = "";
                                ac.TargetControlID = controlName;
                                ac.ServiceMethod = param.DataSource;
                                ac.ServicePath = "../Services/PatientService.asmx";
                                ac.UseContextKey = true;
                                ac.EnableCaching = true;
                                ac.MinimumPrefixLength = 1;
                                ac.CompletionInterval = 500;
                                tc.Controls.Add(ac);
                                lstParameteSchedule.Remove(paramName);
                                break;
                            }
                        }
                        break;
                    case 3:
                        DropDownList ddl = new DropDownList();

                        foreach (var paramName in lstParameteSchedule)
                        {
                            if (paramName.ParameterName == param.DisplayName.Replace(" ", ""))
                            {
                                ddl.ID = controlName;
                                var data = ReportData.GetKeyValueData(param.DataSource, companyId); //param.DataSource
                                ddl.DataSource = data;
                                ddl.DataTextField = "Value";
                                ddl.DataValueField = "Key";
                                ddl.DataBind();
                                if (param.DataSource != "GroupBy")
                                {
                                    ddl.Items.Insert(0, new ListItem("--" + param.DisplayName + "--", "NA"));
                                }
                                ddl.SelectedValue = paramName.Value;
                                ddl.CssClass = "form-control";
                                tc.Controls.Add(ddl);
                                lstParameteSchedule.Remove(paramName);
                                break;
                            }
                        }
                        break;
                    case 4:
                        RadComboBox rbddl = new RadComboBox();
                        foreach (var paramName in lstParameteSchedule)
                        {
                            if (paramName.ParameterName == param.DisplayName.Replace(" ", ""))
                            {
                                rbddl.EmptyMessage = "- Select -";
                                rbddl.EnableCheckAllItemsCheckBox = true;
                                rbddl.CheckBoxes = true;
                                rbddl.RenderMode = RenderMode.Lightweight;
                                rbddl.Style.Add("width", "100%");
                                rbddl.ID = controlName;
                                var rbdata = ReportData.GetKeyValueData(param.DataSource, companyId); //param.DataSource
                                rbddl.Filter = RadComboBoxFilter.Contains;
                                rbddl.DataSource = rbdata;
                                rbddl.DataTextField = "Value";
                                rbddl.DataValueField = "Key";
                                rbddl.DataBind();
                                rbddl.ClearSelection();
                                if (paramName.Value != null)
                                {
                                    int k = 0;
                                    string[] parameters = paramName.Value.Split(',');
                                    foreach (RadComboBoxItem x in rbddl.Items)
                                    {
                                        if (k < parameters.Length && parameters[k] == (x.Value))
                                        {
                                            x.Checked = true;
                                            k++;
                                        }
                                    }
                                }
                                rbddl.EnableViewState = false;
                                tc.Controls.Add(rbddl);
                                lstParameteSchedule.Remove(paramName);
                                break;
                            }
                        }
                        break;
                    case 5:
                        CheckBox cb = new CheckBox();
                        cb.Text = param.DisplayName;
                        cb.ID = controlName;
                        cb.CssClass = "chk1 checkbox1 checkbox-inline center-block innerStyleChk";

                        tc.Controls.Add(cb);
                        break;
                    case 6:
                        break;
                    case 7:
                        RadioButton rb = new RadioButton();
                        rb.Text = param.DisplayName;
                        rb.ID = controlName;
                        rb.CssClass = "form-control";
                        tc.Controls.Add(rb);
                        break;
                    case 8:
                        foreach (var paramName in lstParameteSchedule)
                        {
                            if (paramName.ParameterName == param.DisplayName.Replace(" ", ""))
                            {
                                System.Web.UI.HtmlControls.HtmlGenericControl calenderDiv = new System.Web.UI.HtmlControls.HtmlGenericControl();
                                System.Web.UI.HtmlControls.HtmlGenericControl innercalenderDiv = new System.Web.UI.HtmlControls.HtmlGenericControl();
                                innercalenderDiv.ID = "div" + controlName;
                                var sb = new System.Text.StringBuilder();

                                sb.Append("<div class='input-append date form_datetime' >");
                                sb.Append("<div class='inner-addon left-addon' >");
                                sb.Append("<i class='glyphicon glyphicon-calendar'></i>");
                                sb.Append("<input type='text' value='" + paramName.Value + "' name='ctl00$ContentPlaceHolder1$ctl03$" + controlName + "' class='form-control' id='" + controlName + "' maxlength='10' onChange='checkValue(this);' />");
                                sb.Append("</div>");
                                sb.Append("<span class='add-on' > <i class='icon-th' > </i> </span>");
                                sb.Append("</div>");
                                innercalenderDiv.InnerHtml = sb.ToString();
                                tc.Controls.Add(innercalenderDiv);
                                HiddenField hdn = new HiddenField();
                                hdn.ID = "hdn" + controlName;
                                hdn.Value = paramName.Value;
                                tc.Controls.Add(hdn);
                                lstParameteSchedule.Remove(paramName);
                                break;
                            }
                        }
                        break;
                    default:
                        break;
                }
                #endregion
                tr.Controls.Add(tc);
                if (paramCounter % NUMBER_OF_PARAMETERS_PER_ROW == 0 || paramCounter == parameterList.Count)
                {
                    tblnew.Controls.Add(tr);
                    tr = new TableRow();
                }
                paramCounter++;
            }
        }
    }
    public class mycontrol : Control
    {
        public int myIntValue { get; set; }
    }
}
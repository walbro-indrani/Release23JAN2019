﻿using ReportViewer.GoGreenBills.BusinessObject;
using Microsoft.Reporting.WebForms;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using System.Linq;

namespace ReportViewer.GoGreenBills.DataLayer
{
    public static class SubscriptionParameter
    {

        public static ArrayList ReportDefaultParam(System.Web.UI.UserControl uc, int ReportId,string companies)
        {
            BusinessObject.ReportParameterschedule rps;
            List<BusinessObject.ReportParameterschedule> lstParameter = new List<BusinessObject.ReportParameterschedule>();

            ArrayList arrLstDefaultParam = new ArrayList();
            ArrayList arrParamSchedule = new ArrayList();

            List<BusinessObject.ReportParameter> ParameterList = ReportData.GetReportParameter(ReportId);

            

            foreach (BusinessObject.ReportParameter param in ParameterList)
            {
                string controlName = (param.DisplayName + param.ParameterTypeID.ToString()).Replace(" ", "");

                switch (param.ParameterTypeID)
                {
                    case 1:
                        if (!string.IsNullOrEmpty(((TextBox)uc.FindControl(param.ParameterId)).Text))
                        {
                            arrLstDefaultParam.Add(CreateReportParameter(param.ParameterName, ((TextBox)uc.FindControl(param.ParameterId)).Text));
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            rps.Value = ((TextBox)uc.FindControl(param.ParameterId)).Text;
                            lstParameter.Add(rps);
                        }
                        else
                        {
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            rps.Value = null;
                            lstParameter.Add(rps);
                        }
                        break;

                    case 2:
                        if (!string.IsNullOrEmpty(((TextBox)uc.FindControl(param.ParameterId)).Text))
                        {
                            arrLstDefaultParam.Add(CreateReportParameter(param.ParameterName, ((TextBox)uc.FindControl(param.ParameterId)).Text));
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            rps.Value = ((TextBox)uc.FindControl(param.ParameterId)).Text;
                            lstParameter.Add(rps);
                        }
                        else
                        {
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            rps.Value = null;
                            lstParameter.Add(rps);
                        }
                        break;
                    case 3:
                        if (!string.IsNullOrEmpty(((DropDownList)uc.FindControl(param.ParameterId)).SelectedValue) && ((DropDownList)uc.FindControl(param.ParameterId)).SelectedValue != "NA")
                        {
                            arrLstDefaultParam.Add(CreateReportParameter(param.ParameterName, ((DropDownList)uc.FindControl(param.ParameterId)).SelectedValue));
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            rps.Value = ((DropDownList)uc.FindControl(param.ParameterId)).SelectedValue;
                            lstParameter.Add(rps);
                        }
                        else
                        {
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            rps.Value = null;
                            lstParameter.Add(rps);
                        }
                        break;
                    case 4:
                        if (((RadComboBox)uc.FindControl(param.ParameterId)).GetCheckedIndices().Length > 0 || param.ParameterId == "AccountName4")
                        {
                            int flag = 0;
                            List<string> lstTemp = new List<string>();
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            foreach (RadComboBoxItem item in ((RadComboBox)uc.FindControl(param.ParameterId)).CheckedItems)
                            {
                                lstTemp.Add(item.Value.ToString());
                                flag = 1;
                            }
                            if(flag == 0)
                            {
                                arrLstDefaultParam.Add(CreateReportParameter(param.ParameterName, companies));
                                rps.Value = null;
                            }
                            else
                            {
                                arrLstDefaultParam.Add(CreateReportParameter(param.ParameterName, lstTemp.Aggregate((x, y) => x + "," + y)));
                                rps.Value = lstTemp.Aggregate((x, y) => x + "," + y);
                            }
                            lstParameter.Add(rps);
                        }
                        else
                        {
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            rps.Value = null;
                            lstParameter.Add(rps);
                        }
                        break;
                    case 8:
                        if (!string.IsNullOrEmpty(((HiddenField)uc.FindControl(param.ParameterId)).Value))
                        {
                            var uiValue = getReportDateString(((HiddenField)uc.FindControl(param.ParameterId)).Value, '/');
                            //arrLstDefaultParam.Add(CreateReportParameter(param.ParameterName, ((HiddenField)uc.FindControl(param.ParameterId)).Value));
                            arrLstDefaultParam.Add(CreateReportParameter(param.ParameterName, uiValue));
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            //rps.Value = ((HiddenField)uc.FindControl(param.ParameterId)).Value;
                            rps.Value = uiValue;
                            lstParameter.Add(rps);
                        }
                        else
                        {
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            rps.Value = null;
                            lstParameter.Add(rps);
                        }
                        break;
                    case 9:// GroupBy Order parameter 
                        arrLstDefaultParam.Add(CreateReportParameter(param.ParameterName, ((HiddenField)uc.FindControl("hdn"+param.ParameterName+param.ParameterTypeID)).Value));
                        rps = new BusinessObject.ReportParameterschedule();
                        rps.ParameterName = param.ParameterName;
                        rps.Value = ((HiddenField)uc.FindControl("hdn" + param.ParameterName + param.ParameterTypeID)).Value;
                        lstParameter.Add(rps);
                        break;
                    case 10:// GroupBy Fields
                        if (((RadListBox)uc.FindControl(controlName)).Items.Count > 0 || param.ParameterId == "AccountName4")
                        {
                            int flag = 0;
                            List<string> lstTemp = new List<string>();
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            foreach (RadListBoxItem item in ((RadListBox)uc.FindControl(controlName)).Items)
                            {
                                lstTemp.Add(item.Value.ToString());
                                flag = 1;
                            }
                            if (flag == 0)
                            {
                                arrLstDefaultParam.Add(CreateReportParameter(param.ParameterName, companies));
                                rps.Value = null;
                            }
                            else
                            {
                                arrLstDefaultParam.Add(CreateReportParameter(param.ParameterName, lstTemp.Aggregate((x, y) => x + "," + y)));
                                rps.Value = lstTemp.Aggregate((x, y) => x + "," + y);
                            }
                            lstParameter.Add(rps);
                        }
                        else
                        {
                            rps = new BusinessObject.ReportParameterschedule();
                            rps.ParameterName = param.ParameterName;
                            rps.Value = null;
                            lstParameter.Add(rps);
                        }
                        break;
                    default:
                        break;

                }
            }

            arrParamSchedule.Add(arrLstDefaultParam);
            arrParamSchedule.Add(lstParameter);

            return arrParamSchedule;
        }

        public static string getReportDateString(string ControlString, char Delimiter)
        {
            if (ControlString.Equals(string.Empty))
                return string.Empty;

            string[] DateString = ControlString.Split(Delimiter);
            return string.Concat( DateString[2], Delimiter, DateString[0] , Delimiter, DateString[1]);
        }

        public static Microsoft.Reporting.WebForms.ReportParameter CreateReportParameter(string paramName, string pramValue)
        {
            Microsoft.Reporting.WebForms.ReportParameter aParam = new Microsoft.Reporting.WebForms.ReportParameter(paramName, pramValue);
            return aParam;
        }

    }
}

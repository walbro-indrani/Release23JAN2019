﻿using Microsoft.ApplicationBlocks.Data;
using ReportViewer.GoGreenBills.BusinessObject;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReportViewer.GoGreenBills.DataLayer
{
    public static class DashboardReport
    {
        private static string _connectionString = ConfigurationManager.AppSettings["Connection_String"].ToString();

        public static List<KeyValuePair> GetTotalRevenue(string companyId, string speciality, string insuranceName, string provider, string interval, string period, string procedureName, string caseType, string fromDate, string toDate)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Companyies",companyId),
                    new SqlParameter("@Specialties", speciality),
                    new SqlParameter("@InsuranceNames",insuranceName),
                    new SqlParameter("@ProvideNames",provider),
                    new SqlParameter("@Interval",interval),
                    new SqlParameter("@Period",period),
                    new SqlParameter("@CaseType",caseType),
                    new SqlParameter("@FromDate",fromDate),
                    new SqlParameter("@ToDate",toDate),
                };

                SqlDataReader dr = SqlHelper.ExecuteReader(_connectionString, CommandType.StoredProcedure, procedureName, parameters.ToArray());

                List<KeyValuePair> list = new List<KeyValuePair>();

                while (dr.Read())
                {
                    if (interval == "" || interval == null)
                    {
                        list.Add(new KeyValuePair
                        {
                            Key = Convert.ToString(dr["DenialReason"]),
                            Value = Convert.ToString(dr["DenialCount"])
                        });
                    }
                    else
                    {
                        list.Add(new KeyValuePair
                        {
                            Key = Convert.ToString(dr["TimePeriod"]),
                            Value = Convert.ToString(dr["Amount"])
                        });
                    }
                }
                return list;
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        public static List<Dictionary<string, object>> GetGraphData(string companyId, string speciality, string insuranceName, string provider, string interval, string period, string ProcedureName, string caseType, string fromDate, string toDate)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Companyies",companyId),
                    new SqlParameter("@Specialties", speciality),
                    new SqlParameter("@InsuranceNames",insuranceName),
                    new SqlParameter("@ProvideNames",provider),
                    new SqlParameter("@Interval",interval),
                    new SqlParameter("@Period",period),
                    new SqlParameter("@CaseType",caseType),
                    new SqlParameter("@FromDate",fromDate),
                    new SqlParameter("@ToDate",toDate),

                };

                DataSet ds = SqlHelper.ExecuteDataset(_connectionString, CommandType.StoredProcedure, ProcedureName, parameters.ToArray());

                List<Dictionary<string, object>> parentRow = new List<Dictionary<string, object>>();
                Dictionary<string, object> childRow;
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in ds.Tables[0].Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    parentRow.Add(childRow);
                }
                return parentRow;

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static List<Dictionary<string, object>> GetByProvider(string companyId, string speciality, string insuranceName, string provider, string interval, string period, string caseType, string fromDate, string toDate)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Companyies",companyId),
                    new SqlParameter("@Specialties", speciality),
                    new SqlParameter("@InsuranceNames",insuranceName),
                    new SqlParameter("@ProvideNames",provider),
                    new SqlParameter("@Interval",interval),
                    new SqlParameter("@Period",period),
                    new SqlParameter("@CaseType",caseType),
                    new SqlParameter("@FromDate",fromDate),
                    new SqlParameter("@ToDate",toDate),

                };

                DataSet ds = SqlHelper.ExecuteDataset(_connectionString, CommandType.StoredProcedure, "Report.DashboardGetTotalRevenueByProvider", parameters.ToArray());

                List<Dictionary<string, object>> parentRow = new List<Dictionary<string, object>>();
                Dictionary<string, object> childRow;
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in ds.Tables[0].Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    parentRow.Add(childRow);
                }
                return parentRow;

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static List<Dictionary<string, object>> GetByInsurance(string companyId, string speciality, string insuranceName, string provider, string interval, string period, string caseType, string fromDate, string toDate)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Companyies",companyId),
                    new SqlParameter("@Specialties", speciality),
                    new SqlParameter("@InsuranceNames",insuranceName),
                    new SqlParameter("@ProvideNames",provider),
                    new SqlParameter("@Interval",interval),
                    new SqlParameter("@Period",period),
                    new SqlParameter("@CaseType",caseType),
                    new SqlParameter("@FromDate",fromDate),
                    new SqlParameter("@ToDate",toDate),

                };

                DataSet ds = SqlHelper.ExecuteDataset(_connectionString, CommandType.StoredProcedure, "Report.DashboardGetTotalRevenueByInsurance", parameters.ToArray());

                List<Dictionary<string, object>> parentRow = new List<Dictionary<string, object>>();
                Dictionary<string, object> childRow;
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in ds.Tables[0].Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    parentRow.Add(childRow);
                }
                return parentRow;

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static List<List<Dictionary<string, object>>> GetAllData(string companyId, string speciality, string insuranceName, string provider, string doctorName, string providerLocation, string interval, string period, string procedure, string caseType, string fromDate, string toDate)
        {
            try
            {
                SqlCommand command = new SqlCommand();
                command.CommandTimeout = 0;
                List<SqlParameter> parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Companyies",companyId),
                    new SqlParameter("@Specialties", speciality),
                    new SqlParameter("@InsuranceNames",insuranceName),
                    new SqlParameter("@ProvideNames",provider),
                    new SqlParameter("@DoctorNames",doctorName),
                    new SqlParameter("@ProviderLocation",providerLocation),
                    new SqlParameter("@Interval",interval),
                    new SqlParameter("@Period",period),
                    new SqlParameter("@CaseType",caseType),
                    new SqlParameter("@FromDate",fromDate),
                    new SqlParameter("@ToDate",toDate),

                };
                
                DataSet ds = SqlHelper.ExecuteDataset(_connectionString, CommandType.StoredProcedure, procedure, parameters.ToArray());

                List<List<Dictionary<string, object>>> parentData = new List<List<Dictionary<string, object>>>();
                List<Dictionary<string, object>> parentRow;
                Dictionary<string, object> childRow;

                foreach (DataTable table in ds.Tables)
                {
                    parentRow = new List<Dictionary<string, object>>();
                    foreach (DataRow row in table.Rows)
                    {
                        childRow = new Dictionary<string, object>();
                        foreach (DataColumn col in table.Columns)
                        {
                            childRow.Add(col.ColumnName, row[col]);
                        }
                        parentRow.Add(childRow);
                    }
                    parentData.Add(parentRow);
                }
                return parentData;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static DataTable GetAccountRecievableAgingReport(string companyId, string reportDate)
        {
            try
            {
                SqlCommand command = new SqlCommand();
                command.CommandTimeout = 0;
                List<SqlParameter> parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Companyies", companyId),
                    new SqlParameter("@ReportDate", reportDate),

                };

                DataSet ds = SqlHelper.ExecuteDataset(_connectionString, CommandType.StoredProcedure, constant.procDashboardGetAccountReceivableAgingReport, parameters.ToArray());

                if(ds.Tables.Count > 0)
                {
                    return ds.Tables[0];
                }
                else
                {
                    return null;
                }
                
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static DataSet DashboardGetAccountReceivableAgingReportDetail(string companyId, string reportDate, string aging)
        {
            try
            {
                SqlCommand command = new SqlCommand();
                command.CommandTimeout = 0;
                List<SqlParameter> parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Companyies", companyId),
                    new SqlParameter("@ReportDate", reportDate),
                    new SqlParameter("@Aging", aging),
                };

                DataSet ds = SqlHelper.ExecuteDataset(_connectionString, CommandType.StoredProcedure, constant.procDashboardGetAccountReceivableAgingReportDetail, parameters.ToArray());

                if (ds.Tables.Count > 0)
                {
                    return ds;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static DataTable detailedExportToExcel_Click(string companyId, string reportDate, string procedure)
        {
            try
            {
                SqlConnection con = new SqlConnection(_connectionString);
                SqlCommand command = new SqlCommand(procedure, con);
                command.CommandTimeout = 0;
                SqlDataAdapter da = new SqlDataAdapter(command);
                command.Parameters.Add(new SqlParameter("@Companyies", companyId));
                command.Parameters.Add(new SqlParameter("@ReportDate", reportDate));
                command.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                command.Connection.Open();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    return dt;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static DataTable GetSingleChart(string companyId, string speciality, string insuranceName, string provider, string interval, string period, string procedure, string caseType, string fromDate, string toDate)
        {
            try
            {
                SqlConnection con = new SqlConnection(_connectionString);
                SqlCommand command = new SqlCommand(procedure, con);
                command.CommandTimeout = 0;
                SqlDataAdapter da = new SqlDataAdapter(command);
                command.Parameters.Add(new SqlParameter("@Companyies", companyId));
                command.Parameters.Add(new SqlParameter("@Specialties", speciality));
                command.Parameters.Add(new SqlParameter("@InsuranceNames", insuranceName));
                command.Parameters.Add(new SqlParameter("@ProvideNames", provider));
                command.Parameters.Add(new SqlParameter("@Interval", interval));
                command.Parameters.Add(new SqlParameter("@Period", period));
                command.Parameters.Add(new SqlParameter("@CaseType", caseType));
                command.Parameters.Add(new SqlParameter("@FromDate", fromDate));
                command.Parameters.Add(new SqlParameter("@ToDate", toDate));
                command.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                command.Connection.Open();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    return dt;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static DataTable GetReportDATA(string companyId, string speciality, string insuranceName, string provider, string doctorName, string providerLocation, string caseType, string interval, string period, string fromDate, string toDate, string procedure)
        {
            try
            {
                SqlConnection con = new SqlConnection(_connectionString);

                SqlCommand command = new SqlCommand(procedure, con);

                command.CommandTimeout = 0;

                SqlDataAdapter da = new SqlDataAdapter(command);

                if (!companyId.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@Companyies", companyId));

                if (!speciality.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@Specialties", speciality));

                if (!insuranceName.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@InsuranceNames", insuranceName));

                if (!provider.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@ProvideNames", provider));

                if (!doctorName.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@DoctorNames", doctorName));

                if (!providerLocation.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@ProviderLocation", providerLocation));

                if (!caseType.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@CaseType", caseType));

                if (!interval.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@Interval", interval));

                if (!period.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@Period", period));

                if (!fromDate.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@FromDate", fromDate));

                if (!toDate.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@ToDate", toDate));

                command.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                command.Connection.Open();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                    return dt;
                else
                    return null;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static DataTable GetVisitSummaryDATA(string companyId, string speciality, string doctorName, string providerLocation, string fromDate, string toDate, string procedure)
        {
            try
            {
                SqlConnection con = new SqlConnection(_connectionString);

                SqlCommand command = new SqlCommand(procedure, con);

                command.CommandTimeout = 0;

                SqlDataAdapter da = new SqlDataAdapter(command);

                if (!companyId.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@Companies", companyId));

                if (!speciality.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@Specialties", speciality));

                if (!providerLocation.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@ProviderLocation", providerLocation));

                if (!doctorName.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@DoctorNames", doctorName));

                if (!fromDate.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@fromdate", fromDate));

                if (!toDate.Equals("null"))
                    command.Parameters.Add(new SqlParameter("@todate", toDate));

                command.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                command.Connection.Open();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                    return dt;
                else
                    return null;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static DataTable GetAmountDataForModel(string companyId, string speciality, string insuranceName, string provider, string doctorName, string providerLocation, string interval, string period, string caseType, string fromDate, string toDate,string sortDate, string check)
        {
            try
            {
                SqlConnection con = new SqlConnection(_connectionString);
                SqlCommand command = new SqlCommand(singleConstant.procDashboardGetAmountReportData, con);
                command.CommandTimeout = 0;
                SqlDataAdapter da = new SqlDataAdapter(command);
                command.Parameters.Add(new SqlParameter("@Companyies", companyId));
                command.Parameters.Add(new SqlParameter("@Specialties", speciality));
                command.Parameters.Add(new SqlParameter("@InsuranceNames", insuranceName));
                command.Parameters.Add(new SqlParameter("@ProvideNames", provider));
                command.Parameters.Add(new SqlParameter("@DoctorNames", doctorName));
                command.Parameters.Add(new SqlParameter("@ProviderLocation", providerLocation));
                command.Parameters.Add(new SqlParameter("@Interval", interval));
                command.Parameters.Add(new SqlParameter("@Period", period));
                command.Parameters.Add(new SqlParameter("@CaseType", caseType));
                command.Parameters.Add(new SqlParameter("@FromDate", fromDate));
                command.Parameters.Add(new SqlParameter("@ToDate", toDate));
                command.Parameters.Add(new SqlParameter("@sortDate", sortDate));
                command.Parameters.Add(new SqlParameter("@whoIsClicked", check));
                command.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                command.Connection.Open();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    return dt;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception e)
            {
                throw e;
            }
        }

    }
}

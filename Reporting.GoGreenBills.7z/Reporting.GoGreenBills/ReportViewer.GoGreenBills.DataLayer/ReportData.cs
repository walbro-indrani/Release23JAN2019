﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReportViewer.GoGreenBills.BusinessObject;
using System.Configuration;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Data;

namespace ReportViewer.GoGreenBills.DataLayer
{
    public static class ReportData
    {
        static string  constr = ConfigurationManager.AppSettings["Connection_String"].ToString();
        private static string connectionStringRS = ConfigurationManager.AppSettings["Connection_StringRS"].ToString();
        #region Report Parameter
        public static List<ReportParameter> GetReportParameter(int reportId)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("@REPORTID",reportId)
            };

            SqlDataReader dr = SqlHelper.ExecuteReader(constr, CommandType.StoredProcedure, "[Report].[spGetReportParameterByID]", parameters.ToArray());

            List<ReportParameter> reportParameter = new List<ReportParameter>();

            while (dr.Read())
            {
                ReportParameter param = new ReportParameter
                {
                    ParameterID = Convert.ToInt32(dr["ID"]),
                    ReportID = Convert.ToInt32(dr["ReportID"]),
                    DisplayName = Convert.ToString(dr["DisplayName"]),
                    ParameterTypeID = Convert.ToInt32(dr["ParameterTypeID"]),
                    ParameterTypeName = Convert.ToString(dr["ParameterTypeName"]),
                    DataSource = Convert.ToString(dr["DataSource"]),
                    ParameterName = Convert.ToString(dr["ParameterName"]),
                    ParameterId = Convert.ToString(dr["ParameterID"])

                };
                reportParameter.Add(param);
            }
            return reportParameter;
        }
        #endregion

        #region GetKeyValueData
        public static List<KeyValuePair> GetKeyValueData(string storedProcedureName, string companyID)
        {
            List<KeyValuePair> list = new List<KeyValuePair>();
            if (storedProcedureName == "" || storedProcedureName == null)
            {
                list.Add(new KeyValuePair { Key = "Scheduled", Value = "Scheduled" });
                list.Add(new KeyValuePair { Key = "Re-Scheduled", Value = "Re-Scheduled" });
                list.Add(new KeyValuePair { Key = "Completed", Value = "Completed" });
                list.Add(new KeyValuePair { Key = "No Show", Value = "No Show" });
            }
            else if(storedProcedureName == "ReportType")
            {
                list.Add(new KeyValuePair { Key = "0",Value = "Denial Report" });
                list.Add(new KeyValuePair { Key = "1", Value = "Payment Report" });
                list.Add(new KeyValuePair { Key = "2", Value = "Verification Report" });
                list.Add(new KeyValuePair { Key = "3", Value = "POM Generation Report" });
            }
            else if(storedProcedureName == "DenialType")
            {
                list.Add(new KeyValuePair { Key = "Bill", Value = "Bill" });
                list.Add(new KeyValuePair { Key = "Case", Value = "Case" });
            }
            else if (storedProcedureName == "GroupBy")
            {
                list.Add(new KeyValuePair { Key = "Provider", Value = "Provider Wise" });
                list.Add(new KeyValuePair { Key = "DoctorName", Value = "Doctor Wise" });
                list.Add(new KeyValuePair { Key = "Bill_Status", Value = "Bill Status Wise" });
                list.Add(new KeyValuePair { Key = "Case_Type", Value = "Case Wise" });
                list.Add(new KeyValuePair { Key = "Account", Value = "Account Wise" });
                list.Add(new KeyValuePair { Key = "Insurance", Value = "Insurance Group Wise" });
                list.Add(new KeyValuePair { Key = "Specialty", Value = "Speciality Wise" });
                list.Add(new KeyValuePair { Key = "Attorney", Value = "Attorney Wise" });
            }
            else if (storedProcedureName == "GroupByForVisit")
            {
                //Account, Speciality, Location, DoctorName
                list.Add(new KeyValuePair { Key = "Account", Value = "Account Wise" });
                list.Add(new KeyValuePair { Key = "Speciality", Value = "Speciality Wise" });
                list.Add(new KeyValuePair { Key = "Location", Value = "Location Wise" });
                list.Add(new KeyValuePair { Key = "Doctor", Value = "DoctorName Wise" });
            }
            else if(storedProcedureName == "ColumnsToBeShown")
            {
                list.Add(new KeyValuePair { Key = "n", Value = "Accident Date" });
                list.Add(new KeyValuePair { Key = "g", Value = "Attorney" });
                list.Add(new KeyValuePair { Key = "o", Value = "Attorney Phone" });
                list.Add(new KeyValuePair { Key = "3", Value = "AssignLaw firm" });
                list.Add(new KeyValuePair { Key = "u", Value = "Bill Amount" });
                list.Add(new KeyValuePair { Key = "s", Value = "Bill Date" });
                list.Add(new KeyValuePair { Key = "a", Value = "Bill No" });
                list.Add(new KeyValuePair { Key = "f", Value = "Bill Status" });
                list.Add(new KeyValuePair { Key = "b", Value = "Case No" });
                list.Add(new KeyValuePair { Key = "j", Value = "Case Status" });
                list.Add(new KeyValuePair { Key = "e", Value = "Case Type" });
                list.Add(new KeyValuePair { Key = "m", Value = "Claim No" });
                list.Add(new KeyValuePair { Key = "q", Value = "Date Of Birth" });
                list.Add(new KeyValuePair { Key = "t", Value = "Date Of Service" });
                list.Add(new KeyValuePair { Key = "1", Value = "Denial Reasons" });
                list.Add(new KeyValuePair { Key = "c", Value = "Doctor Name" });
                list.Add(new KeyValuePair { Key = "i", Value = "Insurance" });
                list.Add(new KeyValuePair { Key = "y", Value = "Location" });
                list.Add(new KeyValuePair { Key = "7", Value = "Non-Voluntary Collection" });
                list.Add(new KeyValuePair { Key = "w", Value = "Out-Standing Amount" });
                list.Add(new KeyValuePair { Key = "v", Value = "Total Collected Amount" });
                list.Add(new KeyValuePair { Key = "d", Value = "Patient Name" });
                list.Add(new KeyValuePair { Key = "l", Value = "Policy No" });
                list.Add(new KeyValuePair { Key = "r", Value = "Policy Holder" });
                list.Add(new KeyValuePair { Key = "z", Value = "Procedure Codes" });
                list.Add(new KeyValuePair { Key = "h", Value = "Provider Name" });
                list.Add(new KeyValuePair { Key = "k", Value = "Speciality" });
                list.Add(new KeyValuePair { Key = "p", Value = "SSN" });
                list.Add(new KeyValuePair { Key = "4", Value = "Transfer Amount" });
                list.Add(new KeyValuePair { Key = "5", Value = "Transfer Date" });
                list.Add(new KeyValuePair { Key = "2", Value = "Verification" });
                list.Add(new KeyValuePair { Key = "6", Value = "Voluntary Collection" });
                list.Add(new KeyValuePair { Key = "x", Value = "Write Off" });
            }
            else if(storedProcedureName == "BillStatusFilter")
            {
                //list.Add(new KeyValuePair { Key = "0", Value = "has EOR Received" });
                list.Add(new KeyValuePair { Key = "1", Value = "has Denial" });
                list.Add(new KeyValuePair { Key = "2", Value = "has Payment" });
                list.Add(new KeyValuePair { Key = "3", Value = "has Verification Received" });
                list.Add(new KeyValuePair { Key = "4", Value = "has Verification Sent" });
            }
            else
            {
                List<SqlParameter> parameters = new List<SqlParameter>
                    {
                        new SqlParameter("@SZ_COMPANY_ID",companyID)
                    };

                SqlDataReader dr = SqlHelper.ExecuteReader(constr, CommandType.StoredProcedure, storedProcedureName, parameters.ToArray());

                //while(dr.)
                while (dr.Read())
                {
                    list.Add(new KeyValuePair
                    {
                        Key = Convert.ToString(dr["CODE"]),
                        Value = Convert.ToString(dr["DESCRIPTION"])
                    });
                }
            }
            return list;
        }
        #endregion

        #region BindDropdown
        public static DataSet BindDropdown(string CompanyId)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("@companyId",CompanyId)
            };

            DataSet ds = SqlHelper.ExecuteDataset(constr, CommandType.StoredProcedure, "Report.spDashboardDropdown", parameters.ToArray());

            return ds;
        }
        #endregion

        public static DataSet UpdateDashboardDropdown(string account, string provider, string providerLoc, string doctor, string speciality)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("@Companyies",account),
                new SqlParameter("@ProvideNames",provider),
                new SqlParameter("@ProviderLocation",providerLoc),
                new SqlParameter("@DoctorNames",doctor),
                new SqlParameter("@Specialties",speciality)
            };

            DataSet ds = SqlHelper.ExecuteDataset(constr, CommandType.StoredProcedure, "Report.DashboardGetDropDownData", parameters.ToArray());

            return ds;
        }

        #region GetTimePeriodRange
        public static List<KeyValuePair> GetTimePeriodRange(string period)
        {
           
            List<KeyValuePair> range = new List<KeyValuePair>();
            if (period == "0" || period == "4") //0 - Weekly
            {
                range.Add(new KeyValuePair { Key = "1d", Value = "Daily" });
                range.Add(new KeyValuePair { Key = "1w", Value = "Weekly" });
            }
            else if (period == "1" || period == "5") // 1- A Month
            {
                range.Add(new KeyValuePair { Key = "1w", Value = "Weekly" });
                range.Add(new KeyValuePair { Key = "1m", Value = "Monthly" });
            }
            else if (period == "2" || period == "6") // 3 - Three Month/Quarter
            {
                range.Add(new KeyValuePair { Key = "1w", Value = "Weekly" });
                range.Add(new KeyValuePair { Key = "1m", Value = "Monthly" });
                range.Add(new KeyValuePair { Key = "3m", Value = "Quarterly" });
            }
            else if (period == "3" || period == "7") // 6 - A Year
            {
                range.Add(new KeyValuePair { Key = "1m", Value = "Monthly" });
                range.Add(new KeyValuePair { Key = "3m", Value = "Quarterly" });
                range.Add(new KeyValuePair { Key = "12m", Value = "Yearly" });
            }
            else if (period == "8") //12 - 5 Years
            {
                range.Add(new KeyValuePair { Key = "12m", Value = "Yearly" });
            }
            return range;
        }
        #endregion

        public static void SaveSubscription(string ReportId, byte[] ParameterValueAsByte, string ReportName, string SubscriptionID, string SubsID, string UserID, string ScheduleType,
                            bool IsDaysChecked, bool IsNoOfDaysChecked, int NoOfDays, int NoOfWeeks, string Weeks, string Months,
                            bool IsWeekOfMonthsChecked, string WeekOfMonth, bool IsCalendarDaysChecked, string CalendarDays,
                            string ScheduleTime, string StartScheduleDate, bool IsStopScheduleDateChecked, string StopScheduleDate,
                            string EmailTo, string Subject, bool IsIncludeReportChecked, bool IsIncludeLinkChecked, string RenderFormat)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionStringRS);
                SqlCommand cmd = new SqlCommand("dbo.spSaveGYBSubscriptionDetails", con);
                cmd.CommandTimeout = 0;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                cmd.Parameters.Add(new SqlParameter("@ReportId", ReportId));
                cmd.Parameters.Add(new SqlParameter("@ParameterValueAsByte", ParameterValueAsByte));
                cmd.Parameters.Add(new SqlParameter("@ReportName", ReportName));
                cmd.Parameters.Add(new SqlParameter("@SubscriptionID", SubscriptionID));
                cmd.Parameters.Add(new SqlParameter("@SubsID", SubsID));
                cmd.Parameters.Add(new SqlParameter("@CreatedByUserID", UserID));
                cmd.Parameters.Add(new SqlParameter("@ScheduleType", ScheduleType));
                cmd.Parameters.Add(new SqlParameter("@IsDaysChecked", IsDaysChecked));
                cmd.Parameters.Add(new SqlParameter("@IsNoOfDaysChecked", IsNoOfDaysChecked));
                cmd.Parameters.Add(new SqlParameter("@NoOfDays", NoOfDays));
                cmd.Parameters.Add(new SqlParameter("@NoOfWeeks", NoOfWeeks));
                cmd.Parameters.Add(new SqlParameter("@Weeks", Weeks));
                cmd.Parameters.Add(new SqlParameter("@Months", Months));
                cmd.Parameters.Add(new SqlParameter("@IsWeekOfMonthsChecked", IsWeekOfMonthsChecked));
                cmd.Parameters.Add(new SqlParameter("@WeekOfMonth", WeekOfMonth));
                cmd.Parameters.Add(new SqlParameter("@IsCalendarDaysChecked", IsCalendarDaysChecked));
                cmd.Parameters.Add(new SqlParameter("@CalendarDays", CalendarDays));
                cmd.Parameters.Add(new SqlParameter("@ScheduleTime", ScheduleTime));
                cmd.Parameters.Add(new SqlParameter("@StartScheduleDate", StartScheduleDate));
                cmd.Parameters.Add(new SqlParameter("@IsStopScheduleDateChecked", IsStopScheduleDateChecked));
                cmd.Parameters.Add(new SqlParameter("@StopSCheduleDate", StopScheduleDate));
                cmd.Parameters.Add(new SqlParameter("@EmailTo", EmailTo));
                cmd.Parameters.Add(new SqlParameter("@Subject", Subject));
                cmd.Parameters.Add(new SqlParameter("@IsIncludeReportChecked", IsIncludeReportChecked));
                cmd.Parameters.Add(new SqlParameter("@IsIncludeLinkChecked", IsIncludeLinkChecked));
                cmd.Parameters.Add(new SqlParameter("@RenderFormat", RenderFormat));
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw e;
            }

        }
    }
}

---- Case Detail Hierarchy Report  -- for UI

--insert into [Report].[ReportList] (ReportName) values ('CaseSummaryReport');

--insert into [Report].[ParameterType] (ParameterTypeName) values ('CheckBoxList');

--Declare @ReportID int ;
--select @ReportID =ID from [Report].[ReportList]  where ReportName = 'CaseSummaryReport';

--insert into [Report].[ReportParameter]
--select 9 ReportID
--, case when  DisplayName = 'GroupBy Order' then 'GroupBy Fields' else DisplayName end DisplayName
--, case when ParameterTypeID = 9 then 10 else  ParameterTypeID end ParameterTypeID
--, DataSource, DataSourceType, OrderBy, ParameterName, ParameterID 
--from [Report].[ReportParameter] 
--where ReportID = 4
--and (select count(ID) from [Report].[ReportParameter]  where ReportID =@ReportID) =0


------------------------------------------------------------------------------------------------------------------------------------------------------------------
----Visit Summary Report insert scripts -- for UI

--insert into [Report].[ReportList] (ReportName) values ('VisitCollectionSummaryReport');

--------------------------------------------------------------------------------------------

--Declare @ReportID int ;
--select @ReportID =ID from [Report].[ReportList]  where ReportName = 'VisitCollectionSummaryReport';

--insert into [Report].[ReportParameter]
--select @ReportID ReportID
--, case when ParameterName='AccountName' then 'Companies'
--		when ParameterName='Provider' then 'Provider Location'
--		when ParameterName='FromBillDate' then 'From date'
--		when ParameterName='ToBillDate' then 'To date'
--		when ParameterName='Speciality' then 'Specialties' 
--		else DisplayName
--	end DisplayName
--, case when ParameterName='DoctorName' then 4
--		else ParameterTypeID
--  end ParameterTypeID
--, case when  ParameterName='AccountName' then '[Report].[GetCompanyList]'
--		 when  ParameterName='GroupByOrder' then 'GroupByForVisit'
--		 when ParameterName='Speciality' then '[Report].[spGetSpecilityListForVisit]'
--		 when ParameterName='Provider' then '[Report].[spGetLocationListForVisit]'
--		 when ParameterName='DoctorName' then '[Report].[spGetDoctorsListForVisit]'
--		else DataSource
--	end DataSource
--, case when ParameterName='DoctorName' then 'Stored Procedure'
--		else DataSourceType
--  end DataSourceType--, ParameterName
--, case when ParameterName  ='AccountName' then 1
--				when ParameterName  = 'Provider' then 2
--				when ParameterName  = 'DoctorName' then 3
--				when ParameterName  = 'Speciality' then 4
--				when ParameterName  = 'FromBillDate' then 5
--				when ParameterName  = 'ToBillDate' then 6
--				when ParameterName  = 'GroupByOrder' then 7
--	end As OrderBy
-- , case when ParameterName='AccountName' then 'Companies'
--		when ParameterName='Provider' then 'ProviderLocation'
--		when ParameterName='FromBillDate' then 'fromdate'
--		when ParameterName='ToBillDate' then 'todate'
--		when ParameterName='Speciality' then 'Specialties' 
--		else ParameterName
--	end ParameterName
--, case when ParameterName='AccountName' then 'Companies'+ cast(ParameterTypeID as varchar)
--		when ParameterName='Provider' then 'ProviderLocation'+ cast(ParameterTypeID as varchar)
--		when ParameterName='FromBillDate' then 'hdnfromdate'+ cast(ParameterTypeID as varchar)
--		when ParameterName='ToBillDate' then 'hdntodate'+ cast(ParameterTypeID as varchar)
--		when ParameterName='Speciality' then 'Specialties' + cast(ParameterTypeID as varchar)
--		when ParameterName='DoctorName' then 'DoctorName4'
--		else ParameterID
--	end ParameterID
-- from [Report].[ReportParameter] 
-- where ReportID = 4 
-- and displayname in ('Account Name','Provider', 'Speciality','Doctor Name','From Bill Date','To Bill Date ','GroupBy Order') 
-- and (select count(ID) from [Report].[ReportParameter]  where ReportID =@ReportID) =0
-- order by Order


-----------------------------------------------------------------------------------------
CREATE PROCEDURE [Report].[spGetDoctorsListForVisit]
(
	@SZ_COMPANY_ID NVARCHAR(MAX)
)
AS
BEGIN
 
	SELECT DISTINCT	
			SZ_DOCTOR_NAME [DESCRIPTION],
			SZ_DOCTOR_ID [CODE]
	FROM	MST_DOCTOR 
	WHERE	SZ_COMPANY_ID IN ( SELECT  value FROM  fn_Split(@SZ_COMPANY_ID, ',')	)
	ORDER BY SZ_DOCTOR_NAME	ASC
	
END
GO

-----------------------------------------------------------------------------------------

CREATE PROCEDURE [Report].[spGetLocationListForVisit]
(
	@SZ_COMPANY_ID NVARCHAR(MAX)
)
AS
BEGIN
 
	SELECT DISTINCT	
			SZ_OFFICE_ADDRESS [DESCRIPTION],
			SZ_OFFICE_ADDRESS [CODE]
	FROM	mst_office 
	WHERE	SZ_COMPANY_ID IN (	SELECT  value	FROM     fn_Split(@SZ_COMPANY_ID, ',')	)
	ORDER BY SZ_OFFICE_ADDRESS	ASC
	
END
GO


-----------------------------------------------------------------------------------------

CREATE PROCEDURE [Report].[spGetSpecilityListForVisit]
(
	@SZ_COMPANY_ID NVARCHAR(MAX)
)
AS
BEGIN
 
	SELECT DISTINCT	
			SZ_PROCEDURE_GROUP [DESCRIPTION],
			SZ_PROCEDURE_GROUP [CODE]
	FROM	mst_procedure_group 
	WHERE	SZ_COMPANY_ID IN (	SELECT  value  FROM     fn_Split(@SZ_COMPANY_ID, ',')	)
	ORDER BY SZ_PROCEDURE_GROUP	ASC
	
END
GO

------------------------------------------------------------------------------------------------------------------------------------

CREATE Procedure [Report].[spVisitCollectionSummaryReportDATA]
	@fromdate nvarchar(20),
	@todate nvarchar(20),
	@Companies nvarchar(max),
	@Specialties NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null
as
begin

select [BILLNO], [Acount],[AcountID], [Speciality],[SpecialityID], [Doctor],[DoctorID],  [Location], [LocationID]
,BilledVisits + UnBilledVisits TotalVisits
,BilledVisits [BilledVisits]
,UnBilledVisits[UnBilledVisits]
,[BillAmount] [BilledAmount]
,[PaidAmount] [TotalPaidAmount]
,[OutStadingAmount] [TotalOutstandingAmount]
from (  
		select e.BilledVisits, e.UnBilledVisits
			, e.sz_bill_number [BILLNO]
			, convert(money,isnull(b.FLT_BILL_AMOUNT,0))[BillAmount]
			, convert(money,isnull(b.MN_PAID,0))[PaidAmount]
			, convert(money,isnull(b.FLT_BALANCE,0)) [OutStadingAmount]
			, c.SZ_COMPANY_NAME   [Acount]
			, b.SZ_COMPANY_ID  [AcountID]
			, d.SZ_DOCTOR_NAME [Doctor]
			, b.SZ_DOCTOR_ID [DoctorID]
			, s.SZ_PROCEDURE_GROUP [Speciality]
			, b.SZ_SPECIALITY_ID [SpecialityID]
			, f.SZ_OFFICE_ADDRESS [Location]
			, d.SZ_OFFICE_ID [LocationID]
			--,s.SZ_BILL_STATUS_NAME [BillStatus]
		from TXN_BILL_TRANSACTIONS b  (nolock)
			join  (select 	count(i_event_id) BilledVisits,  0 UnBilledVisits 
					, sz_bill_number 
					, SZ_COMPANY_ID
					, [SZ_DOCTOR_ID]
				from TXN_CALENDAR_EVENT  (nolock) 
				where DT_EVENT_DATE between convert(date,@fromdate) and convert(date,@todate)
				and sz_company_id in( SELECT VALUE FROM FN_SPLIT(@Companies,','))
				and BT_STATUS = 1
				group by sz_bill_number, SZ_COMPANY_ID, [SZ_DOCTOR_ID]
					) e 
				on b.sz_bill_number=e.sz_bill_number
			join  MST_DOCTOR d  (nolock) on b.SZ_DOCTOR_ID=d.SZ_DOCTOR_ID
			join  mst_office f  (nolock) on d.SZ_OFFICE_ID=f.sz_office_id
			join mst_procedure_group s  (nolock) on s.SZ_PROCEDURE_GROUP_ID=b.SZ_SPECIALITY_ID
			join mst_billing_company c  (nolock) on c.SZ_COMPANY_ID=b.SZ_COMPANY_ID
			--join MST_BILL_STATUS s  (nolock) on b.SZ_BILL_STATUS_ID=s.SZ_BILL_STATUS_ID
	union
		--unbilled
		select e.BilledVisits
			, e.UnBilledVisits
			, isnull(e.sz_bill_number, 'NA') [BILLNO]
			--, e.i_event_id [EVENTID]
			, 0 [BillAmount]
			,0 [PaidAmount]
			,0 [OutStadingAmount]
			,c.SZ_COMPANY_NAME [Acount]
			,e.SZ_COMPANY_ID [AcountID]
			,d.SZ_DOCTOR_NAME [Doctor]
			,e.SZ_DOCTOR_ID [DoctorID]
			,s.SZ_PROCEDURE_GROUP [Speciality]
			,ds.SZ_PROCEDURE_GROUP_ID [SpecialityID]
			,f.SZ_OFFICE_ADDRESS [Location]
			,d.SZ_OFFICE_ID [LocationID]
			--,s.SZ_BILL_STATUS_NAME [BillStatus]
		from   (select 0 BilledVisits, count(i_event_id) UnBilledVisits 
					, isnull(sz_bill_number, 'NA') sz_bill_number
					, [SZ_COMPANY_ID]
					, [SZ_DOCTOR_ID]
					--, [SZ_BILL_STATUS_ID]
				from TXN_CALENDAR_EVENT  (nolock) 
				where DT_EVENT_DATE between convert(date,@fromdate) and convert(date,@todate)
				and sz_company_id in( SELECT VALUE FROM FN_SPLIT(@Companies,','))
				and BT_STATUS = 0 --and sz_bill_number is not null
				group by isnull(sz_bill_number, 'NA'), [SZ_COMPANY_ID], [SZ_DOCTOR_ID]--, [SZ_BILL_STATUS_ID]
					) e 
				--on t1.sz_bill_number=e.sz_bill_number
			join  MST_DOCTOR d  (nolock) on e.SZ_DOCTOR_ID=d.SZ_DOCTOR_ID
			join  mst_office f  (nolock) on d.SZ_OFFICE_ID=f.sz_office_id
			join TXN_DOCTOR_SPECIALITY ds  (nolock) on ds.sz_doctor_id=d.sz_doctor_id
			join mst_procedure_group s (nolock) on s.SZ_PROCEDURE_GROUP_ID=ds.SZ_PROCEDURE_GROUP_ID
			join mst_billing_company c  (nolock) on c.SZ_COMPANY_ID=e.SZ_COMPANY_ID
			--join MST_BILL_STATUS s  (nolock) on e.SZ_BILL_STATUS_ID=s.SZ_BILL_STATUS_ID
 )  as m
 where  ( @DoctorNames IS NULL OR ( [Doctor] in (SELECT VALUE FROM FN_SPLIT(@DoctorNames,','))	)	)
	and ( @Specialties is null or ( [Speciality] in (SELECT VALUE FROM FN_SPLIT(@Specialties,','))	)	)
	--and ( @ProviderLocation is null or ( [LocationID] in (SELECT VALUE FROM FN_SPLIT(@ProviderLocation,','))	)	)
	and ( @ProviderLocation is null or ( [Location] in (SELECT VALUE FROM FN_SPLIT(@ProviderLocation,','))	)	)
order by [Acount], [Speciality], [Location], [LocationID], [Doctor], [DoctorID]

	
end
GO

------------------------------------------------------------------------------------------------------------------------------------

CREATE Procedure [Report].[spVisitCollectionSummaryReport]
	@fromdate nvarchar(20),
	@todate nvarchar(20),
	@Companies nvarchar(max),
	@Specialties NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null
as
begin

select [Account], [Speciality], [Location], [LocationID], [Doctor], [DoctorID]
,sum(BilledVisits + UnBilledVisits) TotalVisits
,sum(BilledVisits) [BilledVisits]
,sum(UnBilledVisits)[UnBilledVisits]
,sum([BillAmount])[BilledAmount]
,sum([PaidAmount]) [TotalPaidAmount]
,sum([OutStadingAmount]) [TotalOutstandingAmount]
from (  
		select e.BilledVisits, e.UnBilledVisits
			, e.sz_bill_number [BILLNO]
			, convert(money,isnull(b.FLT_BILL_AMOUNT,0))[BillAmount]
			,convert(money,isnull(b.MN_PAID,0))[PaidAmount]
			,convert(money,isnull(b.FLT_BALANCE,0)) [OutStadingAmount]
			,c.SZ_COMPANY_NAME   [Account]
			,b.SZ_COMPANY_ID  [AccountID]
			,d.SZ_DOCTOR_NAME [Doctor]
			,b.SZ_DOCTOR_ID [DoctorID]
			,s.SZ_PROCEDURE_GROUP [Speciality]
			,b.SZ_SPECIALITY_ID [SpecialityID]
			,f.SZ_OFFICE_ADDRESS [Location]
			,d.SZ_OFFICE_ID [LocationID]
			--,s.SZ_BILL_STATUS_NAME [BillStatus]
		from TXN_BILL_TRANSACTIONS b  (nolock)
			join  (select 	count(i_event_id) BilledVisits,  0 UnBilledVisits 
					, sz_bill_number 
					, SZ_COMPANY_ID
					, [SZ_DOCTOR_ID]
				from TXN_CALENDAR_EVENT  (nolock) 
				where DT_EVENT_DATE between convert(date,@fromdate) and convert(date,@todate)
				and sz_company_id in( SELECT VALUE FROM FN_SPLIT(@Companies,','))
				and BT_STATUS = 1
				group by sz_bill_number, SZ_COMPANY_ID, [SZ_DOCTOR_ID]
					) e 
				on b.sz_bill_number=e.sz_bill_number
			join  MST_DOCTOR d  (nolock) on b.SZ_DOCTOR_ID=d.SZ_DOCTOR_ID
			join  mst_office f  (nolock) on d.SZ_OFFICE_ID=f.sz_office_id
			join mst_procedure_group s  (nolock) on s.SZ_PROCEDURE_GROUP_ID=b.SZ_SPECIALITY_ID
			join mst_billing_company c  (nolock) on c.SZ_COMPANY_ID=b.SZ_COMPANY_ID
			--join MST_BILL_STATUS s  (nolock) on b.SZ_BILL_STATUS_ID=s.SZ_BILL_STATUS_ID

	union
		--unbilled
		select e.BilledVisits
			, e.UnBilledVisits
			, isnull(e.sz_bill_number, 'NA') [BILLNO]
			--, e.i_event_id [EVENTID]
			, 0 [BillAmount]
			,0 [PaidAmount]
			,0 [OutStadingAmount]
			,c.SZ_COMPANY_NAME [Account]
			,e.SZ_COMPANY_ID [AccountID]
			,d.SZ_DOCTOR_NAME [Doctor]
			,e.SZ_DOCTOR_ID [DoctorID]
			,s.SZ_PROCEDURE_GROUP [Speciality]
			,ds.SZ_PROCEDURE_GROUP_ID [SpecialityID]
			,f.SZ_OFFICE_ADDRESS [Location]
			,d.SZ_OFFICE_ID [LocationID]
			--,s.SZ_BILL_STATUS_NAME [BillStatus]
		from   (select 0 BilledVisits, count(i_event_id) UnBilledVisits 
					, isnull(sz_bill_number, 'NA') sz_bill_number
					, [SZ_COMPANY_ID]
					, [SZ_DOCTOR_ID]
					--, [SZ_BILL_STATUS_ID]
				from TXN_CALENDAR_EVENT  (nolock) 
				where DT_EVENT_DATE between convert(date,@fromdate) and convert(date,@todate)
				and sz_company_id in( SELECT VALUE FROM FN_SPLIT(@Companies,','))
				and BT_STATUS = 0 --and sz_bill_number is not null
				group by isnull(sz_bill_number, 'NA'), [SZ_COMPANY_ID], [SZ_DOCTOR_ID]--, [SZ_BILL_STATUS_ID]
					) e 
				--on t1.sz_bill_number=e.sz_bill_number
			join  MST_DOCTOR d  (nolock) on e.SZ_DOCTOR_ID=d.SZ_DOCTOR_ID
			join  mst_office f  (nolock) on d.SZ_OFFICE_ID=f.sz_office_id
			join TXN_DOCTOR_SPECIALITY ds  (nolock) on ds.sz_doctor_id=d.sz_doctor_id
			join mst_procedure_group s (nolock) on s.SZ_PROCEDURE_GROUP_ID=ds.SZ_PROCEDURE_GROUP_ID
			join mst_billing_company c  (nolock) on c.SZ_COMPANY_ID=e.SZ_COMPANY_ID
			--join MST_BILL_STATUS s  (nolock) on e.SZ_BILL_STATUS_ID=s.SZ_BILL_STATUS_ID
 )  as m
 where  ( @DoctorNames IS NULL OR ( [Doctor] in (SELECT VALUE FROM FN_SPLIT(@DoctorNames,','))	)	)
	and ( @Specialties is null or ( [Speciality] in (SELECT VALUE FROM FN_SPLIT(@Specialties,','))	)	)
	--and ( @ProviderLocation is null or ( [LocationID] in (SELECT VALUE FROM FN_SPLIT(@ProviderLocation,','))	)	)
	and ( @ProviderLocation is null or ( [Location] in (SELECT VALUE FROM FN_SPLIT(@ProviderLocation,','))	)	)
group by [Account], [AccountID], [Doctor], [DoctorID], [Speciality], [SpecialityID], [Location], [LocationID]
order by [Account], [Speciality], [Location], [LocationID], [Doctor], [DoctorID]

	
end
GO

------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------

ALTER PROCEDURE [Report].[DashboardGetPendingReceivableByInsurance] --[Report].[DashboardGetPendingReceivableByInsurance] null,null,null,null,null,'yearly','Last 5 Years','12/31/2017','1/1/2017'
	@Companyies NVARCHAR(MAX) = null,
	@Specialties NVARCHAR(MAX) = null,
	@InsuranceNames NVARCHAR(MAX) = null,
	@ProvideNames NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@CaseType NVARCHAR(MAX) = null,
	@Interval VARCHAR(50) = null,
	@Period VARCHAR(100) = null,
	@ToDate DATETIME = null,
	@FromDate DATETIME = null

AS
BEGIN
	
	IF(@ToDate IS NULL OR @ToDate = '')
	BEGIN
		SET @ToDate  = CONVERT(DATETIME, CONVERT(VARCHAR(10), GETDATE(), 103 ), 103)
	END

	IF(@FromDate IS NULL OR @FromDate = '')
	BEGIN
		SET	@FromDate  = CASE 
			WHEN @Period = 'Last Week' THEN DATEADD(WEEK, -1, @ToDate)
			WHEN @Period = 'Last Month' THEN DATEADD(MONTH, -1, @ToDate)
			WHEN @Period = 'Last Quarter' THEN DATEADD(MONTH, -3, @ToDate)
			WHEN @Period = 'Last Year' THEN DATEADD(YEAR, -1, @ToDate)
			WHEN @Period = 'Last 5 Years' THEN DATEADD(YEAR, -5, @ToDate)
			END	
	END
	
	IF OBJECT_ID('tempdb..#Data') IS NOT NULL
	BEGIN
		DROP TABLE #Data
	END

	CREATE TABLE #Data 
	(
		InsuranceCompanyName VARCHAR(MAX),
		TimePeriod VARCHAR(100),
		Amount DECIMAL(18,2),
		PaidAmount DECIMAL(18,2),
		BillAmount DECIMAL(18,2),
		WritenOffAmount DECIMAL(18,2),
		BillCount DECIMAL(18,0),
		PeriodNumber INT,
		BillDate DateTime 
	)
	IF OBJECT_ID('tempdb..#CTE') IS NOT NULL
	BEGIN
		DROP TABLE #CTE
	END

	CREATE TABLE #CTE
	(
		InsuranceCheckSum VARCHAR(100),
		Amount Decimal(18,2),
		BillDate DateTime,
		Number int
	)

	DECLARE @AccountFilter TABLE(AccountIDCheckSum INT PRIMARY KEY)
	INSERT @AccountFilter(AccountIDCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@Companyies, ',')

	DECLARE @CaseTypeFilter TABLE(CaseTypeIdCheckSum INT PRIMARY KEY)
	INSERT @CaseTypeFilter(CaseTypeIdCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@CaseType, ',')

	IF(@Interval = 'Daily' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount, BillDate, Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				[BillDate] = b.BillDate,
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.DayOfMonth, b.InsuranceCheckSum,b.BillDate
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber,
			BillDate
		)
		SELECT	rd.InsuranceCompanyName,
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName,d.DayName,D.DayOfMonth,rd.BillDate
		UNION 
		SELECT	'Others',
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.DayOfMonth,d.DayName,rd.BillDate
		ORDER	BY d.DayOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END
	
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.WeekOfQuarter
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfQuarter
		ORDER	BY d.WeekOfQuarter
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Month, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount,
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount, 
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
		
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY  d.MonthNameShort, d.Month, rd.InsuranceCompanyName
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Yearly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN

		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.InsuranceCheckSum									
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		ORDER	BY d.Year
	END

	ELSE IF(@Interval = 'Yearly' AND @Period = 'Last 5 Years')
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY b.InsuranceCheckSum

		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber,
			BillDate
		)
		SELECT	rd.InsuranceCompanyName,
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		ORDER	BY d.Year
	
	END

	--SELECT * FROM #Data

	DECLARE @masterQuery as NVARCHAR(MAX),
		
		@cols AS NVARCHAR(MAX),
		@query  AS NVARCHAR(MAX),

		@PAcols AS NVARCHAR(MAX),
		@PAquery  AS NVARCHAR(MAX),

		@BAcols AS NVARCHAR(MAX),
		@BAquery  AS NVARCHAR(MAX),

		@WAcols AS NVARCHAR(MAX),
		@WAquery  AS NVARCHAR(MAX),

		@BCcols AS NVARCHAR(MAX),
		@BCquery  AS NVARCHAR(MAX)

	select @cols = STUFF((SELECT ',' + QUOTENAME(InsuranceCompanyName) 
						from #Data
						group by InsuranceCompanyName
						order by InsuranceCompanyName
				FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)') 
			,1,1,'')

	-- Appending the Speciality with prefixed Code
	select @PAcols = REPLACE(@cols, '[', '[PA+'); -- PA is Paid Amount
	select @BAcols = REPLACE(@cols, '[', '[BA+'); -- BA is Bill Amount
	select @WAcols = REPLACE(@cols, '[', '[WA+'); -- PA is WrittenOff Amount
	select @BCcols = REPLACE(@cols, '[', '[BC+'); -- BC is Bills Count


	--select @PAcols PAcols
	--select @BAcols BAcols
	--select @WAcols WAcols
	--select @BCcols BCcols

	set @query = 'SELECT PeriodNumber, TimePeriod,' + @cols + ' from 
				 (
					select PeriodNumber, TimePeriod, InsuranceCompanyName, Amount = ISNULL(Amount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for InsuranceCompanyName in (' + @cols + ')
				) p '
	
	set @PAquery = 'SELECT PeriodNumber, TimePeriod,' + @PAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''PA+''+InsuranceCompanyName InsuranceCompanyName, Amount = ISNULL(PaidAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for InsuranceCompanyName in (' + @PAcols + ')
				) p '

	
	set @BAquery = 'SELECT PeriodNumber, TimePeriod,' + @BAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''BA+''+InsuranceCompanyName InsuranceCompanyName, Amount = ISNULL(BillAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for InsuranceCompanyName in (' + @BAcols + ')
				) p '

	set @WAquery = 'SELECT PeriodNumber, TimePeriod,' + @WAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''WA+''+InsuranceCompanyName InsuranceCompanyName, Amount = ISNULL(WritenOffAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for InsuranceCompanyName in (' + @WAcols + ')
				) p '

	set @BCquery = 'SELECT PeriodNumber, TimePeriod,' + @BCcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''BC+''+InsuranceCompanyName InsuranceCompanyName, Amount = ISNULL(BillCount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for InsuranceCompanyName in (' + @BCcols + ')
				) p '
				
	SET @masterQuery = 'SELECT A.*, ' + @PAcols + ',' + @BAcols + ',' + @WAcols + ','  + @BCcols  + 
						' FROM (' + @query + ') AS A 
						INNER JOIN (' + @PAquery + ') as B ON (A.PeriodNumber = B.PeriodNumber and A.TimePeriod = B.TimePeriod)
						INNER JOIN (' + @BAquery + ') as C ON (B.PeriodNumber = C.PeriodNumber and B.TimePeriod = C.TimePeriod)
						INNER JOIN (' + @WAquery + ') as D ON (C.PeriodNumber = D.PeriodNumber and C.TimePeriod = D.TimePeriod)
						INNER JOIN (' + @BCquery + ') as E ON (D.PeriodNumber = E.PeriodNumber and D.TimePeriod = E.TimePeriod)
						ORDER BY A.PeriodNumber';
	execute(@masterQuery)
END
GO


------------------------------------------------------------------------------------------------------------------------------------------------------------------

ALTER PROCEDURE [Report].[DashboardGetPendingReceivableByProvider] --[Report].[DashboardGetPendingReceivableByProvider] null,null,null,null,null,'yearly','Last 5 Years','12/31/2017','1/1/2017'
	@Companyies NVARCHAR(MAX) = null,
	@Specialties NVARCHAR(MAX) = null,
	@InsuranceNames NVARCHAR(MAX) = null,
	@ProvideNames NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@CaseType NVARCHAR(MAX) = null,
	@Interval VARCHAR(50) = null,
	@Period VARCHAR(100) = null,
	@ToDate DATETIME = null,
	@FromDate DATETIME = null

AS
BEGIN
	
	IF(@ToDate IS NULL OR @ToDate = '')
	BEGIN
		SET @ToDate  = CONVERT(DATETIME, CONVERT(VARCHAR(10), GETDATE(), 103 ), 103)
	END

	IF(@FromDate IS NULL OR @FromDate = '')
	BEGIN
		SET	@FromDate  = CASE 
			WHEN @Period = 'Last Week' THEN DATEADD(WEEK, -1, @ToDate)
			WHEN @Period = 'Last Month' THEN DATEADD(MONTH, -1, @ToDate)
			WHEN @Period = 'Last Quarter' THEN DATEADD(MONTH, -3, @ToDate)
			WHEN @Period = 'Last Year' THEN DATEADD(YEAR, -1, @ToDate)
			WHEN @Period = 'Last 5 Years' THEN DATEADD(YEAR, -5, @ToDate)
			END	
	END
	
	IF OBJECT_ID('tempdb..#Data') IS NOT NULL
	BEGIN
		DROP TABLE #Data
	END

	CREATE TABLE #Data 
	(
		ProviderName VARCHAR(MAX),
		TimePeriod VARCHAR(100),
		Amount DECIMAL(18,2),
		PaidAmount DECIMAL(18,2),
		BillAmount DECIMAL(18,2),
		WritenOffAmount DECIMAL(18,2),
		BillCount DECIMAL(18,0),
		PeriodNumber INT,
		BillDate DateTime 
	)

	IF OBJECT_ID('tempdb..#CTE') IS NOT NULL
	BEGIN
		DROP TABLE #CTE
	END

	CREATE TABLE #CTE
	(
		ProviderCheckSum VARCHAR(100),
		Amount Decimal(18,2),
		BillDate DateTime,
		Number int
	)

	DECLARE @AccountFilter TABLE(AccountIDCheckSum INT PRIMARY KEY)
	INSERT @AccountFilter(AccountIDCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@Companyies, ',')

	DECLARE @CaseTypeFilter TABLE(CaseTypeIdCheckSum INT PRIMARY KEY)
	INSERT @CaseTypeFilter(CaseTypeIdCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@CaseType, ',')

	IF(@Interval = 'Daily' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount, BillDate, Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				[BillDate] = b.BillDate,
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.DayOfMonth, b.ProviderCheckSum,b.BillDate
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber,
			BillDate
		)
		SELECT	rd.ProviderName,
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName,d.DayName,D.DayOfMonth,rd.BillDate
		UNION 
		SELECT	'Others',
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.DayOfMonth,d.DayName,rd.BillDate
		ORDER	BY d.DayOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum , Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum  = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum  = rd.ProviderCheckSum 
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.WeekOfQuarter
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfQuarter
		ORDER	BY d.WeekOfQuarter
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Month, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY  d.MonthNameShort, d.Month, rd.ProviderName
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount,
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount, 
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Yearly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.ProviderCheckSum									
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		ORDER	BY d.Year
	END

	ELSE IF(@Interval = 'Yearly' AND @Period = 'Last 5 Years')
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY b.ProviderCheckSum

		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		ORDER	BY d.Year
	
	END

	--SELECT * FROM #Data

	DECLARE @masterQuery as NVARCHAR(MAX),
		
		@cols AS NVARCHAR(MAX),
		@query  AS NVARCHAR(MAX),

		@PAcols AS NVARCHAR(MAX),
		@PAquery  AS NVARCHAR(MAX),

		@BAcols AS NVARCHAR(MAX),
		@BAquery  AS NVARCHAR(MAX),

		@WAcols AS NVARCHAR(MAX),
		@WAquery  AS NVARCHAR(MAX),

		@BCcols AS NVARCHAR(MAX),
		@BCquery  AS NVARCHAR(MAX)

	select @cols = STUFF((SELECT ',' + QUOTENAME(ProviderName) 
						from #Data
						group by ProviderName
						order by ProviderName
				FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)') 
			,1,1,'')

	-- Appending the Speciality with prefixed Code
	select @PAcols = REPLACE(@cols, '[', '[PA+'); -- PA is Paid Amount
	select @BAcols = REPLACE(@cols, '[', '[BA+'); -- BA is Bill Amount
	select @WAcols = REPLACE(@cols, '[', '[WA+'); -- PA is WrittenOff Amount
	select @BCcols = REPLACE(@cols, '[', '[BC+'); -- BC is Bills Count

	
	--select @cols cols;
	--select @PAcols PACols;
	--select @BAcols BACols; 
	--select @WAcols WACols;
	--select @BCcols BCcols;

	set @query = 'SELECT PeriodNumber, TimePeriod,' + @cols + ' from 
				 (
					select PeriodNumber, TimePeriod, ProviderName, Amount = ISNULL(Amount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for ProviderName in (' + @cols + ')
				) p '

	set @PAquery = 'SELECT PeriodNumber, TimePeriod,' + @PAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''PA+''+ProviderName ProviderName, Amount = ISNULL(PaidAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for ProviderName in (' + @PAcols + ')
				) p '

	
	set @BAquery = 'SELECT PeriodNumber, TimePeriod,' + @BAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''BA+''+ProviderName ProviderName, Amount = ISNULL(BillAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for ProviderName in (' + @BAcols + ')
				) p '

	set @WAquery = 'SELECT PeriodNumber, TimePeriod,' + @WAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''WA+''+ProviderName ProviderName, Amount = ISNULL(WritenOffAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for ProviderName in (' + @WAcols + ')
				) p '

	set @BCquery = 'SELECT PeriodNumber, TimePeriod,' + @BCcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''BC+''+ProviderName ProviderName, Amount = ISNULL(BillCount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for ProviderName in (' + @BCcols + ')
				) p '
				
	SET @masterQuery = 'SELECT A.*, ' + @PAcols + ',' + @BAcols + ',' + @WAcols + ','  + @BCcols  + 
						' FROM (' + @query + ') AS A 
						INNER JOIN (' + @PAquery + ') as B ON (A.PeriodNumber = B.PeriodNumber and A.TimePeriod = B.TimePeriod)
						INNER JOIN (' + @BAquery + ') as C ON (B.PeriodNumber = C.PeriodNumber and B.TimePeriod = C.TimePeriod)
						INNER JOIN (' + @WAquery + ') as D ON (C.PeriodNumber = D.PeriodNumber and C.TimePeriod = D.TimePeriod)
						INNER JOIN (' + @BCquery + ') as E ON (D.PeriodNumber = E.PeriodNumber and D.TimePeriod = E.TimePeriod)
						ORDER BY A.PeriodNumber';					

	execute(@masterQuery)
END
GO



----------------------------------------------------------------------------------------------------------------------------------------------------------------

ALTER PROCEDURE [Report].[DashboardGetPendingReceivableBySpecialty] --[Report].[DashboardGetPendingReceivableBySpecialty] null,null,null,null,null,'yearly','Last 5 Years','12/31/2017','1/1/2017'
	@Companyies NVARCHAR(MAX) = null,
	@Specialties NVARCHAR(MAX) = null,
	@InsuranceNames NVARCHAR(MAX) = null,
	@ProvideNames NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@CaseType NVARCHAR(MAX) = null,
	@Interval VARCHAR(50) = null,
	@Period VARCHAR(100) = null,
	@ToDate DATETIME = null,
	@FromDate DATETIME = null

AS
BEGIN

	IF(@ToDate IS NULL OR @ToDate = '')
	BEGIN
		SET @ToDate  = CONVERT(DATETIME, CONVERT(VARCHAR(10), GETDATE(), 103 ), 103)
	END

	IF(@FromDate IS NULL OR @FromDate = '')
	BEGIN
		SET	@FromDate  = CASE 
			WHEN @Period = 'Last Week' THEN DATEADD(WEEK, -1, @ToDate)
			WHEN @Period = 'Last Month' THEN DATEADD(MONTH, -1, @ToDate)
			WHEN @Period = 'Last Quarter' THEN DATEADD(MONTH, -3, @ToDate)
			WHEN @Period = 'Last Year' THEN DATEADD(YEAR, -1, @ToDate)
			WHEN @Period = 'Last 5 Years' THEN DATEADD(YEAR, -5, @ToDate)
			END	
	END
	
	IF OBJECT_ID('tempdb..#Data') IS NOT NULL
	BEGIN
		DROP TABLE #Data
	END

	CREATE TABLE #Data 
	(
		SpecialityName VARCHAR(100),
		TimePeriod VARCHAR(100),
		Amount DECIMAL(18,2),
		PaidAmount DECIMAL(18,2),
		BillAmount DECIMAL(18,2),
		WritenOffAmount DECIMAL(18,2),
		BillCount DECIMAL(18,0),
		PeriodNumber INT,
		BillDate DateTime
	)

	IF OBJECT_ID('tempdb..#CTE') IS NOT NULL
	BEGIN
		DROP TABLE #CTE
	END

	CREATE TABLE #CTE
	(
		SpecialtyCheckSum VARCHAR(100),
		Amount Decimal(18,2),
		BillDate DateTime,
		Number int
	)

	DECLARE @AccountFilter TABLE(AccountIDCheckSum INT PRIMARY KEY)
	INSERT @AccountFilter(AccountIDCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@Companyies, ',')

	DECLARE @CaseTypeFilter TABLE(CaseTypeIdCheckSum INT PRIMARY KEY)
	INSERT @CaseTypeFilter(CaseTypeIdCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@CaseType, ',')

	IF(@Interval = 'Daily' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount, BillDate, Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				[BillDate] = b.BillDate,
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.DayOfMonth, b.SpecialtyCheckSum,b.BillDate
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber,
			BillDate
		)
		SELECT	rd.SpecialtyName,
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName,d.DayName,D.DayOfMonth,rd.BillDate
		UNION 
		SELECT	'Others',
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.DayOfMonth,d.DayName,rd.BillDate
		ORDER	BY d.DayOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END
	
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.WeekOfQuarter
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfQuarter
		ORDER	BY d.WeekOfQuarter
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Month, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
		
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY  d.MonthNameShort, d.Month, rd.SpecialtyName
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Yearly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN

		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.SpecialtyCheckSum									
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		ORDER	BY d.Year
	END

	ELSE IF(@Interval = 'Yearly' AND @Period = 'Last 5 Years')
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(OutstandingAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY b.SpecialtyCheckSum

		--INSERT	#Data(SpecialityName, TimePeriod, Amount, PeriodNumber)
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			BillAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(OutstandingAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				BillAmount = ISNULL(SUM(rd.BillAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		ORDER	BY d.Year
	
	END

	--SELECT * FROM #Data

	DECLARE @masterQuery as NVARCHAR(MAX),
		
		@cols AS NVARCHAR(MAX),
		@query  AS NVARCHAR(MAX),

		@PAcols AS NVARCHAR(MAX),
		@PAquery  AS NVARCHAR(MAX),

		@BAcols AS NVARCHAR(MAX),
		@BAquery  AS NVARCHAR(MAX),

		@WAcols AS NVARCHAR(MAX),
		@WAquery  AS NVARCHAR(MAX),

		@BCcols AS NVARCHAR(MAX),
		@BCquery  AS NVARCHAR(MAX)


	select @cols = STUFF((SELECT ',' + QUOTENAME(SpecialityName) 
						from #Data
						group by SpecialityName
						order by SpecialityName
				FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)') 
			,1,1,'')

	-- Appending the Speciality with prefixed Code
	select @PAcols = REPLACE(@cols, '[', '[PA+'); -- PA is Paid Amount
	select @BAcols = REPLACE(@cols, '[', '[BA+'); -- BA is Bill Amount
	select @WAcols = REPLACE(@cols, '[', '[WA+'); -- PA is WrittenOff Amount
	select @BCcols = REPLACE(@cols, '[', '[BC+'); -- BC is Bills Count

	
	--select @cols cols;
	--select @PAcols PACols;
	--select @BAcols BACols; 
	--select @WAcols WACols;
	--select @BCcols BCcols;

	set @query = 'SELECT PeriodNumber, TimePeriod,' + @cols + ' from 
				 (
					select PeriodNumber, TimePeriod, SpecialityName, Amount = ISNULL(Amount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for SpecialityName in (' + @cols + ')
				) p '
	set @PAquery = 'SELECT PeriodNumber, TimePeriod,' + @PAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''PA+''+SpecialityName SpecialityName, Amount = ISNULL(PaidAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for SpecialityName in (' + @PAcols + ')
				) p '

	
	set @BAquery = 'SELECT PeriodNumber, TimePeriod,' + @BAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''BA+''+SpecialityName SpecialityName, Amount = ISNULL(BillAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for SpecialityName in (' + @BAcols + ')
				) p '

	set @WAquery = 'SELECT PeriodNumber, TimePeriod,' + @WAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''WA+''+SpecialityName SpecialityName, Amount = ISNULL(WritenOffAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for SpecialityName in (' + @WAcols + ')
				) p '

	set @BCquery = 'SELECT PeriodNumber, TimePeriod,' + @BCcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''BC+''+SpecialityName SpecialityName, Amount = ISNULL(BillCount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for SpecialityName in (' + @BCcols + ')
				) p '
				
	SET @masterQuery = 'SELECT A.*, ' + @PAcols + ',' + @BAcols + ',' + @WAcols + ','  + @BCcols  + 
						' FROM (' + @query + ') AS A 
						INNER JOIN (' + @PAquery + ') as B ON (A.PeriodNumber = B.PeriodNumber and A.TimePeriod = B.TimePeriod)
						INNER JOIN (' + @BAquery + ') as C ON (B.PeriodNumber = C.PeriodNumber and B.TimePeriod = C.TimePeriod)
						INNER JOIN (' + @WAquery + ') as D ON (C.PeriodNumber = D.PeriodNumber and C.TimePeriod = D.TimePeriod)
						INNER JOIN (' + @BCquery + ') as E ON (D.PeriodNumber = E.PeriodNumber and D.TimePeriod = E.TimePeriod)
						ORDER BY PeriodNumber';

	--execute(@query)

	--select @masterQuery

	execute(@masterQuery)
END
GO


-------------------------------------------------------------------------------------------------------------------------------------------------------
ALTER PROCEDURE [Report].[DashboardGetTotalPendingReceivableReport]
	@Companyies NVARCHAR(MAX) = null,
	@Specialties NVARCHAR(MAX) = null,
	@InsuranceNames NVARCHAR(MAX) = null,
	@ProvideNames NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@CaseType NVARCHAR(MAX) = null,
	@Interval VARCHAR(50) = null,
	@Period VARCHAR(100) = null,
	@To_Date DATETIME = null,
	@From_Date DATETIME = null

AS
BEGIN
	DECLARE @ToDate DATETIME,
			@FromDate DATETIME 
	
	IF(@To_Date IS NULL OR @To_Date = '' AND @From_Date IS NULL OR @From_Date = '')
	BEGIN
		SET @ToDate  = CONVERT(DATETIME, CONVERT(VARCHAR(10), GETDATE(), 103 ), 103)
		SET	@FromDate  = CASE 
			WHEN @Period = 'Last Week' THEN DATEADD(WEEK, -1, @ToDate)
			WHEN @Period = 'Last Month' THEN DATEADD(MONTH, -1, @ToDate)
			WHEN @Period = 'Last Quarter' THEN DATEADD(MONTH, -3, @ToDate)
			WHEN @Period = 'Last Year' THEN DATEADD(YEAR, -1, @ToDate)
			WHEN @Period = 'Last 5 Years' THEN DATEADD(YEAR, -5, @ToDate)
			END	
		
	END
	ELSE
	BEGIN
		SET @ToDate = @To_Date
		SET	@FromDate = @From_Date
	END
	
	
	DECLARE @AccountFilter TABLE(AccountIDCheckSum INT PRIMARY KEY)
	INSERT @AccountFilter(AccountIDCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@Companyies, ',')

	DECLARE @CaseTypeFilter TABLE(CaseTypeIdCheckSum INT PRIMARY KEY)
	INSERT @CaseTypeFilter(CaseTypeIdCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@CaseType, ',')

	IF(@Interval = 'Daily' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		SELECT	TimePeriod = LEFT(d.DayName,3),
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.DayOfMonth,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON RD.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.DayOfMonth,d.DayName 
		ORDER	BY d.DayOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		--SELECT	TimePeriod = 'W-' + CAST(d.WeekOfMonth AS VARCHAR), OutstandingAmount= ISNULL(SUM(OutstandingAmount),0), PeriodNumber = d.WeekOfMonth
		SELECT	TimePeriod = 'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				OutstandingAmount= ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.WeekOfMonth,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		--SELECT	TimePeriod = 'W-' + CAST(d.WeekOfMonth AS VARCHAR), OutstandingAmount = ISNULL(SUM(OutstandingAmount),0), PeriodNumber = d.WeekOfMonth
		SELECT	TimePeriod = 'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				OutstandingAmount= ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.WeekOfMonth,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		--SELECT	TimePeriod = 'W-' + CAST(d.WeekOfQuarter AS VARCHAR), OutstandingAmount = ISNULL(SUM(OutstandingAmount), 0), PeriodNumber = d.WeekOfQuarter
		SELECT	TimePeriod = 'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				OutstandingAmount= ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.WeekOfQuarter,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.WeekOfQuarter
		ORDER	BY d.WeekOfQuarter
	END
	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		--SELECT	TimePeriod = d.MonthNameShort, OutstandingAmount = ISNULL(SUM(OutstandingAmount),0), PeriodNumber = d.Month
		SELECT	TimePeriod = d.MonthNameShort,
				OutstandingAmount= ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.Month,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.MonthNameShort, d.Month
		ORDER	BY d.MonthNameShort, d.Month
	END
	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		--SELECT	TimePeriod = d.MonthNameShort, OutstandingAmount = ISNULL(SUM(OutstandingAmount),0), PeriodNumber = d.Month
		SELECT	TimePeriod = d.MonthNameShort,
				OutstandingAmount= ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.Month,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END
	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		--SELECT	TimePeriod = d.MonthNameShort, OutstandingAmount = ISNULL(SUM(OutstandingAmount),0), PeriodNumber = d.Month
		SELECT	TimePeriod = d.MonthNameShort,
				OutstandingAmount= ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.Month,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END
	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		--SELECT	TimePeriod = 'Q-' + CAST(d.Quarter AS VARCHAR), OutstandingAmount = ISNULL(SUM(OutstandingAmount),0), PeriodNumber = d.Quarter
		SELECT	TimePeriod = 'Q-' + CAST(d.Quarter AS VARCHAR),
				OutstandingAmount= ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.Quarter,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END
	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		--SELECT	TimePeriod = 'Q-' + CAST(d.Quarter AS VARCHAR), OutstandingAmount = ISNULL(SUM(OutstandingAmount),0), PeriodNumber = d.Quarter
		SELECT	TimePeriod = 'Q-' + CAST(d.Quarter AS VARCHAR),
				OutstandingAmount= ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.Quarter,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END
	ELSE IF(@Interval = 'Yearly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		--SELECT	TimePeriod = d.Year, OutstandingAmount = ISNULL(SUM(OutstandingAmount),0), PeriodNumber = d.Year
		SELECT	TimePeriod = d.Year,
				OutstandingAmount= ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.Year,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.Year
		ORDER	BY d.Year
	END
	ELSE IF(@Interval = 'Yearly' AND @Period = 'Last 5 Years')
	BEGIN
		--SELECT	TimePeriod = d.Year, OutstandingAmount = ISNULL(SUM(OutstandingAmount),0), PeriodNumber = d.Year
		SELECT	TimePeriod = d.Year,
				OutstandingAmount= ISNULL(SUM(OutstandingAmount),0),
				PeriodNumber = d.Year,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.[Date]
		WHERE	rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		GROUP	BY d.Year
		ORDER	BY d.Year
	END
END

GO

------------------------------------------------------------------------------------------------------------------------------------------------------------
ALTER PROCEDURE [Report].[DashboardGetTotalRevenueByInsurance] --[Report].[DashboardGetTotalRevenueByInsurance] null,null,null,null,null,'yearly','Last 5 Years','12/31/2017','1/1/2017'
	@Companyies NVARCHAR(MAX) = null,
	@Specialties NVARCHAR(MAX) = null,
	@InsuranceNames NVARCHAR(MAX) = null,
	@ProvideNames NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@CaseType NVARCHAR(MAX) = null,
	@Interval VARCHAR(50) = null,
	@Period VARCHAR(100) = null,
	@ToDate DATETIME = null,
	@FromDate DATETIME = null

AS
BEGIN
	
	IF(@ToDate IS NULL OR @ToDate = '')
	BEGIN
		SET @ToDate  = CONVERT(DATETIME, CONVERT(VARCHAR(10), GETDATE(), 103 ), 103)
	END

	IF(@FromDate IS NULL OR @FromDate = '')
	BEGIN
		SET	@FromDate  = CASE 
			WHEN @Period = 'Last Week' THEN DATEADD(WEEK, -1, @ToDate)
			WHEN @Period = 'Last Month' THEN DATEADD(MONTH, -1, @ToDate)
			WHEN @Period = 'Last Quarter' THEN DATEADD(MONTH, -3, @ToDate)
			WHEN @Period = 'Last Year' THEN DATEADD(YEAR, -1, @ToDate)
			WHEN @Period = 'Last 5 Years' THEN DATEADD(YEAR, -5, @ToDate)
			END	
	END
	
	IF OBJECT_ID('tempdb..#Data') IS NOT NULL
	BEGIN
		DROP TABLE #Data
	END

	CREATE TABLE #Data 
	(
		InsuranceCompanyName VARCHAR(MAX),
		TimePeriod VARCHAR(100),
		Amount DECIMAL(18,2),
		PaidAmount DECIMAL(18,2),
		OutstandingAmount DECIMAL(18,2),
		WritenOffAmount DECIMAL(18,2),
		BillCount DECIMAL(18,0),
		PeriodNumber INT,
		BillDate DateTime 
	)
	IF OBJECT_ID('tempdb..#CTE') IS NOT NULL
	BEGIN
		DROP TABLE #CTE
	END

	CREATE TABLE #CTE
	(
		InsuranceCheckSum VARCHAR(100),
		Amount Decimal(18,2),
		BillDate DateTime,
		Number int
	)

	DECLARE @AccountFilter TABLE(AccountIDCheckSum INT PRIMARY KEY)
	INSERT @AccountFilter(AccountIDCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@Companyies, ',')

	DECLARE @CaseTypeFilter TABLE(CaseTypeIdCheckSum INT PRIMARY KEY)
	INSERT @CaseTypeFilter(CaseTypeIdCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@CaseType, ',')

	IF(@Interval = 'Daily' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount, BillDate, Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				[BillDate] = b.BillDate,
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.DayOfMonth, b.InsuranceCheckSum,b.BillDate
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber,
			BillDate
		)
		SELECT	rd.InsuranceCompanyName,
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName,d.DayName,D.DayOfMonth,rd.BillDate
		UNION 
		SELECT	'Others',
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.DayOfMonth,d.DayName,rd.BillDate
		ORDER	BY d.DayOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(b.BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(b.BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END
	
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(b.BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.WeekOfQuarter
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfQuarter
		ORDER	BY d.WeekOfQuarter
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(b.BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Month, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(b.BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
		
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(b.BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY  d.MonthNameShort, d.Month, rd.InsuranceCompanyName
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(b.BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(b.BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.InsuranceCheckSum
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Yearly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN

		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(b.BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.InsuranceCheckSum									
		
		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				d.Year,
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		ORDER	BY d.Year
	END

	ELSE IF(@Interval = 'Yearly' AND @Period = 'Last 5 Years')
	BEGIN
		INSERT	#CTE(InsuranceCheckSum, Amount,Number)
		SELECT	b.InsuranceCheckSum,
				Amount = ISNULL(SUM(b.BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY b.InsuranceCheckSum

		INSERT	#Data
		(
			InsuranceCompanyName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.InsuranceCompanyName,
				d.Year,
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.InsuranceCompanyName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(rd.BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.InsuranceCheckSum = rd.InsuranceCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		ORDER	BY d.Year
	
	END

	--SELECT * FROM #Data

	DECLARE @masterQuery as NVARCHAR(MAX),
		
		@cols AS NVARCHAR(MAX),
		@query  AS NVARCHAR(MAX),

		@PAcols AS NVARCHAR(MAX),
		@PAquery  AS NVARCHAR(MAX),

		@OAcols AS NVARCHAR(MAX),
		@OAquery  AS NVARCHAR(MAX),

		@WAcols AS NVARCHAR(MAX),
		@WAquery  AS NVARCHAR(MAX),

		@BCcols AS NVARCHAR(MAX),
		@BCquery  AS NVARCHAR(MAX)

	select @cols = STUFF((SELECT ',' + QUOTENAME(InsuranceCompanyName) 
						from #Data
						group by InsuranceCompanyName
						order by InsuranceCompanyName
				FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)') 
			,1,1,'')

			-- Appending the Speciality with prefixed Code
	select @PAcols = REPLACE(@cols, '[', '[PA+'); -- PA is Paid Amount
	select @OAcols = REPLACE(@cols, '[', '[OA+'); -- OA is OutStanding Amount
	select @WAcols = REPLACE(@cols, '[', '[WA+'); -- PA is WrittenOff Amount
	select @BCcols = REPLACE(@cols, '[', '[BC+'); -- BC is Bills Count

	set @query = 'SELECT PeriodNumber, TimePeriod,' + @cols + ' from 
				 (
					select PeriodNumber, TimePeriod, InsuranceCompanyName, Amount = ISNULL(Amount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for InsuranceCompanyName in (' + @cols + ')
				) p '

	set @PAquery = 'SELECT PeriodNumber, TimePeriod,' + @PAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''PA+''+InsuranceCompanyName InsuranceCompanyName, Amount = ISNULL(PaidAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for InsuranceCompanyName in (' + @PAcols + ')
				) p '

	
	set @OAquery = 'SELECT PeriodNumber, TimePeriod,' + @OAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''OA+''+InsuranceCompanyName InsuranceCompanyName, Amount = ISNULL(OutstandingAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for InsuranceCompanyName in (' + @OAcols + ')
				) p '

	set @WAquery = 'SELECT PeriodNumber, TimePeriod,' + @WAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''WA+''+InsuranceCompanyName InsuranceCompanyName, Amount = ISNULL(WritenOffAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for InsuranceCompanyName in (' + @WAcols + ')
				) p '

	set @BCquery = 'SELECT PeriodNumber, TimePeriod,' + @BCcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''BC+''+InsuranceCompanyName InsuranceCompanyName, Amount = ISNULL(BillCount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for InsuranceCompanyName in (' + @BCcols + ')
				) p '
				
	SET @masterQuery = 'SELECT A.*, ' + @PAcols + ',' + @OAcols + ',' + @WAcols + ','  + @BCcols  + 
						' FROM (' + @query + ') AS A 
						INNER JOIN (' + @PAquery + ') as B ON (A.PeriodNumber = B.PeriodNumber and A.TimePeriod = B.TimePeriod)
						INNER JOIN (' + @OAquery + ') as C ON (B.PeriodNumber = C.PeriodNumber and B.TimePeriod = C.TimePeriod)
						INNER JOIN (' + @WAquery + ') as D ON (C.PeriodNumber = D.PeriodNumber and C.TimePeriod = D.TimePeriod)
						INNER JOIN (' + @BCquery + ') as E ON (D.PeriodNumber = E.PeriodNumber and D.TimePeriod = E.TimePeriod)
						ORDER BY PeriodNumber';


	execute(@masterQuery)
END
GO


------------------------------------------------------------------------------------------------------------------------------------------------------------------
ALTER PROCEDURE [Report].[DashboardGetTotalRevenueByProvider] --[Report].[DashboardGetTotalRevenueByProvider] null,null,null,null,null,'yearly','Last 5 Years','12/31/2017','1/1/2017'
	@Companyies NVARCHAR(MAX) = null,
	@Specialties NVARCHAR(MAX) = null,
	@InsuranceNames NVARCHAR(MAX) = null,
	@ProvideNames NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@CaseType NVARCHAR(MAX) = null,
	@Interval VARCHAR(50) = null,
	@Period VARCHAR(100) = null,
	@ToDate DATETIME = null,
	@FromDate DATETIME = null

AS
BEGIN
	
	IF(@ToDate IS NULL OR @ToDate = '')
	BEGIN
		SET @ToDate  = CONVERT(DATETIME, CONVERT(VARCHAR(10), GETDATE(), 103 ), 103)
	END

	IF(@FromDate IS NULL OR @FromDate = '')
	BEGIN
		SET	@FromDate  = CASE 
			WHEN @Period = 'Last Week' THEN DATEADD(WEEK, -1, @ToDate)
			WHEN @Period = 'Last Month' THEN DATEADD(MONTH, -1, @ToDate)
			WHEN @Period = 'Last Quarter' THEN DATEADD(MONTH, -3, @ToDate)
			WHEN @Period = 'Last Year' THEN DATEADD(YEAR, -1, @ToDate)
			WHEN @Period = 'Last 5 Years' THEN DATEADD(YEAR, -5, @ToDate)
			END	
	END
	
	IF OBJECT_ID('tempdb..#Data') IS NOT NULL
	BEGIN
		DROP TABLE #Data
	END

	CREATE TABLE #Data 
	(
		ProviderName VARCHAR(MAX),
		TimePeriod VARCHAR(100),
		Amount DECIMAL(18,2),
		PaidAmount DECIMAL(18,2),
		OutstandingAmount DECIMAL(18,2),
		WritenOffAmount DECIMAL(18,2),
		BillCount DECIMAL(18,0),
		PeriodNumber INT,
		BillDate DateTime 
	)
	IF OBJECT_ID('tempdb..#CTE') IS NOT NULL
	BEGIN
		DROP TABLE #CTE
	END

	CREATE TABLE #CTE
	(
		ProviderCheckSum VARCHAR(100),
		Amount Decimal(18,2),
		BillDate DateTime,
		Number int
	)

	DECLARE @AccountFilter TABLE(AccountIDCheckSum INT PRIMARY KEY)
	INSERT @AccountFilter(AccountIDCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@Companyies, ',')

	DECLARE @CaseTypeFilter TABLE(CaseTypeIdCheckSum INT PRIMARY KEY)
	INSERT @CaseTypeFilter(CaseTypeIdCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@CaseType, ',')

	IF(@Interval = 'Daily' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount, BillDate, Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				[BillDate] = b.BillDate,
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.DayOfMonth, b.ProviderCheckSum,b.BillDate
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber,
			BillDate
		)
		SELECT	rd.ProviderName,
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName,d.DayName,D.DayOfMonth,rd.BillDate
		UNION 
		SELECT	'Others',
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.DayOfMonth,d.DayName,rd.BillDate
		ORDER	BY d.DayOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum , Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum  = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum  = rd.ProviderCheckSum 
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		ORDER	BY d.WeekOfMonth
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.WeekOfQuarter
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfQuarter
		ORDER	BY d.WeekOfQuarter
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Month, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Monthly' AND ( @Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY  d.MonthNameShort, d.Month, rd.ProviderName
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.ProviderCheckSum
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Yearly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.ProviderCheckSum									
		
		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				d.Year,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		ORDER	BY d.Year
	END

	ELSE IF(@Interval = 'Yearly' AND @Period = 'Last 5 Years')
	BEGIN
		INSERT	#CTE(ProviderCheckSum, Amount,Number)
		SELECT	b.ProviderCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY b.ProviderCheckSum

		INSERT	#Data
		(
			ProviderName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.ProviderName,
				d.Year,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.ProviderName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(BillAmount),0),
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),
				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.ProviderCheckSum = rd.ProviderCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		ORDER	BY d.Year
	
	END

	--SELECT * FROM #Data

	DECLARE @masterQuery as NVARCHAR(MAX),
		
		@cols AS NVARCHAR(MAX),
		@query  AS NVARCHAR(MAX),

		@PAcols AS NVARCHAR(MAX),
		@PAquery  AS NVARCHAR(MAX),

		@OAcols AS NVARCHAR(MAX),
		@OAquery  AS NVARCHAR(MAX),

		@WAcols AS NVARCHAR(MAX),
		@WAquery  AS NVARCHAR(MAX),

		@BCcols AS NVARCHAR(MAX),
		@BCquery  AS NVARCHAR(MAX)

	select @cols = STUFF((SELECT ',' + QUOTENAME(ProviderName) 
						from #Data
						group by ProviderName
						order by ProviderName
				FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)') 
			,1,1,'')

	-- Appending the Speciality with prefixed Code
	select @PAcols = REPLACE(@cols, '[', '[PA+'); -- PA is Paid Amount
	select @OAcols = REPLACE(@cols, '[', '[OA+'); -- OA is OutStanding Amount
	select @WAcols = REPLACE(@cols, '[', '[WA+'); -- PA is WrittenOff Amount
	select @BCcols = REPLACE(@cols, '[', '[BC+'); -- BC is Bills Count

	set @query = 'SELECT PeriodNumber, TimePeriod,' + @cols + ' from 
				 (
					select PeriodNumber, TimePeriod, ProviderName, Amount = ISNULL(Amount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for ProviderName in (' + @cols + ')
				) p '

	set @PAquery = 'SELECT PeriodNumber, TimePeriod,' + @PAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''PA+''+ProviderName ProviderName, Amount = ISNULL(PaidAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for ProviderName in (' + @PAcols + ')
				) p '

	
	set @OAquery = 'SELECT PeriodNumber, TimePeriod,' + @OAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''OA+''+ProviderName ProviderName, Amount = ISNULL(OutstandingAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for ProviderName in (' + @OAcols + ')
				) p '

	set @WAquery = 'SELECT PeriodNumber, TimePeriod,' + @WAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''WA+''+ProviderName ProviderName, Amount = ISNULL(WritenOffAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for ProviderName in (' + @WAcols + ')
				) p '

	set @BCquery = 'SELECT PeriodNumber, TimePeriod,' + @BCcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''BC+''+ProviderName ProviderName, Amount = ISNULL(BillCount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for ProviderName in (' + @BCcols + ')
				) p '
				
	SET @masterQuery = 'SELECT A.*, ' + @PAcols + ',' + @OAcols + ',' + @WAcols + ','  + @BCcols  + 
						' FROM (' + @query + ') AS A 
						INNER JOIN (' + @PAquery + ') as B ON (A.PeriodNumber = B.PeriodNumber and A.TimePeriod = B.TimePeriod)
						INNER JOIN (' + @OAquery + ') as C ON (B.PeriodNumber = C.PeriodNumber and B.TimePeriod = C.TimePeriod)
						INNER JOIN (' + @WAquery + ') as D ON (C.PeriodNumber = D.PeriodNumber and C.TimePeriod = D.TimePeriod)
						INNER JOIN (' + @BCquery + ') as E ON (D.PeriodNumber = E.PeriodNumber and D.TimePeriod = E.TimePeriod)
						ORDER BY PeriodNumber';

	--execute(@query)
	execute(@masterQuery)
END
GO



--------------------------------------------------------------------------------------------------------------------------------------------------------------
ALTER PROCEDURE [Report].[DashboardGetTotalRevenueBySpecialty] --[Report].[DashboardGetTotalRevenueBySpecialty] null,null,null,null,null,null,NUll,'yearly','Last 5 Years','12/31/2017','1/1/2017'
	@Companyies NVARCHAR(MAX) = null,
	@Specialties NVARCHAR(MAX) = null,
	@InsuranceNames NVARCHAR(MAX) = null,
	@ProvideNames NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@CaseType NVARCHAR(MAX) = null,
	@Interval VARCHAR(50) = null,
	@Period VARCHAR(100) = null,
	@ToDate DATETIME = null,
	@FromDate DATETIME = null

AS
BEGIN
	
	IF(@ToDate IS NULL OR @ToDate = '')
	BEGIN
		SET @ToDate  = CONVERT(DATETIME, CONVERT(VARCHAR(10), GETDATE(), 103 ), 103)
	END

	IF(@FromDate IS NULL OR @FromDate = '')
	BEGIN
		SET	@FromDate  = CASE 
			WHEN @Period = 'Last Week' THEN DATEADD(WEEK, -1, @ToDate)
			WHEN @Period = 'Last Month' THEN DATEADD(MONTH, -1, @ToDate)
			WHEN @Period = 'Last Quarter' THEN DATEADD(MONTH, -3, @ToDate)
			WHEN @Period = 'Last Year' THEN DATEADD(YEAR, -1, @ToDate)
			WHEN @Period = 'Last 5 Years' THEN DATEADD(YEAR, -5, @ToDate)
			END	
	END
	
	IF OBJECT_ID('tempdb..#Data') IS NOT NULL
	BEGIN
		DROP TABLE #Data
	END

	CREATE TABLE #Data 
	(
		SpecialityName VARCHAR(100),
		TimePeriod VARCHAR(100),
		Amount DECIMAL(18,2),
		PaidAmount DECIMAL(18,2),
		OutstandingAmount DECIMAL(18,2),
		WritenOffAmount DECIMAL(18,2),
		BillCount DECIMAL(18,0),
		PeriodNumber INT,
		BillDate DateTime
	)
	IF OBJECT_ID('tempdb..#CTE') IS NOT NULL
	BEGIN
		DROP TABLE #CTE
	END

	CREATE TABLE #CTE
	(
		SpecialtyCheckSum VARCHAR(100),
		Amount Decimal(18,2),
		BillDate DateTime,
		Number int
	)

	DECLARE @AccountFilter TABLE(AccountIDCheckSum INT PRIMARY KEY)
	INSERT @AccountFilter(AccountIDCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@Companyies, ',')

	DECLARE @CaseTypeFilter TABLE(CaseTypeIdCheckSum INT PRIMARY KEY)
	INSERT @CaseTypeFilter(CaseTypeIdCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@CaseType, ',')

	IF(@Interval = 'Daily' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,BillDate, Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				[BillDate] = b.BillDate,
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.DayOfMonth, b.SpecialtyCheckSum,b.BillDate
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber,
			BillDate
		)
		SELECT	rd.SpecialtyName,
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(BillAmount),0),
				
				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(rd.BillNumber),

				PeriodNumber = d.DayOfMonth,
				--D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName,d.DayName,D.DayOfMonth,rd.BillDate
		UNION 
		SELECT	'Others',
				LEFT(d.DayName,3),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(rd.PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(rd.OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(rd.WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				PeriodNumber = d.DayOfMonth,
				--D.DayOfMonth,
				rd.BillDate
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		AND		c.BillDate = RD.BillDate
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.DayOfMonth,d.DayName,rd.BillDate
		--ORDER	BY d.DayOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		--ORDER	BY d.WeekOfMonth
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.WeekOfMonth, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.WeekOfMonth
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfMonth AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.WeekOfMonth
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfMonth
		--ORDER	BY d.WeekOfMonth
		
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount =ISNULL(SUM(BillAmount),0),
				
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.WeekOfQuarter
		UNION 
		SELECT	'Others',
				'W-' + CAST(d.WeekOfQuarter AS VARCHAR),
				Amount =ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.WeekOfQuarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.WeekOfQuarter
		--ORDER	BY d.WeekOfQuarter
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Month, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),
				
				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		--ORDER	BY d.Month
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.MonthNameShort, d.Month
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		--ORDER	BY d.Month
		
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, 
				Amount,
		        Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY  d.MonthNameShort, d.Month, rd.SpecialtyName
		UNION 
		SELECT	'Others',
				d.MonthNameShort,
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Month
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY  d.MonthNameShort, d.Month
		--ORDER	BY d.Month
	END
	

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Quarter, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		--ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.SpecialtyCheckSum
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount, 
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount,
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.Quarter
		UNION 
		SELECT	'Others',
				'Q-' + CAST(d.Quarter AS VARCHAR),
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Quarter
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Quarter
		--ORDER	BY d.Quarter
	END

	ELSE IF(@Interval = 'Yearly' AND ( @Period = 'Last Year' or @Period = 'This Year'))
	BEGIN

		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY a.Year, b.SpecialtyCheckSum									
		
		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount,
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount, 
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				d.Year,
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		--ORDER	BY d.Year
	END

	ELSE IF(@Interval = 'Yearly' AND @Period = 'Last 5 Years')
	BEGIN
		INSERT	#CTE(SpecialtyCheckSum, Amount,Number)
		SELECT	b.SpecialtyCheckSum,
				Amount = ISNULL(SUM(BillAmount),0),
				ROW_NUMBER() over (ORDER BY  COUNT(1) DESC) AS Number
		FROM	[Report].[DimDate] a
		JOIN	[Report].[FactBills] b WITH (NOLOCK) ON b.BillDate = a.[Date]
		WHERE	(@Specialties IS NULL OR b.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR b.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR b.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR b.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR b.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR b.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR b.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		b.BillDate >= @FromDate
		AND		b.BillDate <= @ToDate
		GROUP	BY b.SpecialtyCheckSum

		INSERT	#Data
		(
			SpecialityName, 
			TimePeriod, 
			Amount,
			PaidAmount,
			OutstandingAmount,
			WritenOffAmount,
			BillCount, 
			PeriodNumber
		)
		SELECT	rd.SpecialtyName,
				d.Year,
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number <= 10
		GROUP	BY rd.SpecialtyName, d.Year
		UNION 
		SELECT	'Others',
				d.Year,
				Amount = ISNULL(SUM(BillAmount),0),

				PaidAmount = ISNULL(SUM(PaidAmount),0), 
				OutstandingAmount = ISNULL(SUM(OutstandingAmount),0),
				WritenOffAmount = ISNULL(SUM(WritenOffAmount),0),
				BillCount = COUNT(BillNumber),

				D.Year
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		JOIN	#CTE c ON c.SpecialtyCheckSum = rd.SpecialtyCheckSum
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		AND		c.Number > 10
		GROUP	BY d.Year
		--ORDER	BY d.Year
	
	END

	--SELECT * FROM #Data

	DECLARE @masterQuery as NVARCHAR(MAX),
		
		@cols AS NVARCHAR(MAX),
		@query  AS NVARCHAR(MAX),

		@PAcols AS NVARCHAR(MAX),
		@PAquery  AS NVARCHAR(MAX),

		@OAcols AS NVARCHAR(MAX),
		@OAquery  AS NVARCHAR(MAX),

		@WAcols AS NVARCHAR(MAX),
		@WAquery  AS NVARCHAR(MAX),

		@BCcols AS NVARCHAR(MAX),
		@BCquery  AS NVARCHAR(MAX)

	select @cols = STUFF((SELECT ',' + QUOTENAME(SpecialityName) 
						from #Data
						group by SpecialityName
						--order by SpecialityName
				FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)') 
			,1,1,'');

	-- Appending the Speciality with prefixed Code
	select @PAcols = REPLACE(@cols, '[', '[PA+'); -- PA is Paid Amount
	select @OAcols = REPLACE(@cols, '[', '[OA+'); -- OA is OutStanding Amount
	select @WAcols = REPLACE(@cols, '[', '[WA+'); -- PA is WrittenOff Amount
	select @BCcols = REPLACE(@cols, '[', '[BC+'); -- BC is Bills Count

	--select @cols cols;
	--select @PAcols PACols;
	--select @OAcols OACols; 
	--select @WAcols WACols;
	--select @BCcols BCcols;
	
	set @query = 'SELECT PeriodNumber, TimePeriod,' + @cols + ' from 
				 (
					select PeriodNumber, TimePeriod, SpecialityName, Amount = ISNULL(Amount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for SpecialityName in (' + @cols + ')
				) p '

	set @PAquery = 'SELECT PeriodNumber, TimePeriod,' + @PAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''PA+''+SpecialityName SpecialityName, Amount = ISNULL(PaidAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for SpecialityName in (' + @PAcols + ')
				) p '

	
	set @OAquery = 'SELECT PeriodNumber, TimePeriod,' + @OAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''OA+''+SpecialityName SpecialityName, Amount = ISNULL(OutstandingAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for SpecialityName in (' + @OAcols + ')
				) p '

	set @WAquery = 'SELECT PeriodNumber, TimePeriod,' + @WAcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''WA+''+SpecialityName SpecialityName, Amount = ISNULL(WritenOffAmount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for SpecialityName in (' + @WAcols + ')
				) p '

	set @BCquery = 'SELECT PeriodNumber, TimePeriod,' + @BCcols + ' from 
				 (
					select PeriodNumber, TimePeriod, ''BC+''+SpecialityName SpecialityName, Amount = ISNULL(BillCount, 0)
					from #Data
				) x
				pivot 
				(
					sum(Amount)
					for SpecialityName in (' + @BCcols + ')
				) p '
				
	SET @masterQuery = 'SELECT A.*, ' + @PAcols + ',' + @OAcols + ',' + @WAcols + ','  + @BCcols  + 
						' FROM (' + @query + ') AS A 
						INNER JOIN (' + @PAquery + ') as B ON (A.PeriodNumber = B.PeriodNumber and A.TimePeriod = B.TimePeriod)
						INNER JOIN (' + @OAquery + ') as C ON (B.PeriodNumber = C.PeriodNumber and B.TimePeriod = C.TimePeriod)
						INNER JOIN (' + @WAquery + ') as D ON (C.PeriodNumber = D.PeriodNumber and C.TimePeriod = D.TimePeriod)
						INNER JOIN (' + @BCquery + ') as E ON (D.PeriodNumber = E.PeriodNumber and D.TimePeriod = E.TimePeriod)
						ORDER BY PeriodNumber';

	--execute(@query)

	--select @masterQuery

	execute(@masterQuery)
END
GO

-------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [Report].[DashboardGetTotalRevenueByInsuranceDATA] 
	@Companyies NVARCHAR(MAX) = null,
	@Specialties NVARCHAR(MAX) = null,
	@InsuranceNames NVARCHAR(MAX) = null,
	@ProvideNames NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@CaseType NVARCHAR(MAX) = null,
	@Interval VARCHAR(50) = null,
	@Period VARCHAR(100) = null,
	@ToDate DATETIME = null,
	@FromDate DATETIME = null

AS
BEGIN
	
	IF(@ToDate IS NULL OR @ToDate = '')
	BEGIN
		SET @ToDate  = CONVERT(DATETIME, CONVERT(VARCHAR(10), GETDATE(), 103 ), 103)
	END

	IF(@FromDate IS NULL OR @FromDate = '')
	BEGIN
		SET	@FromDate  = 
			CASE 
				WHEN @Period = 'Last Week' THEN DATEADD(WEEK, -1, @ToDate)
				WHEN @Period = 'Last Month' THEN DATEADD(MONTH, -1, @ToDate)
				WHEN @Period = 'Last Quarter' THEN DATEADD(MONTH, -3, @ToDate)
				WHEN @Period = 'Last Year' THEN DATEADD(YEAR, -1, @ToDate)
				WHEN @Period = 'Last 5 Years' THEN DATEADD(YEAR, -5, @ToDate)
			END	
	END

	
	DECLARE @AccountFilter TABLE(AccountIDCheckSum INT PRIMARY KEY)
	INSERT @AccountFilter(AccountIDCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@Companyies, ',')

	DECLARE @CaseTypeFilter TABLE(CaseTypeIdCheckSum INT PRIMARY KEY)
	INSERT @CaseTypeFilter(CaseTypeIdCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@CaseType, ',')

	IF(@Interval = 'Daily' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		
		SELECT	LEFT(d.DayName,3) TimePeriod,
				d.DayOfMonth PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(rd.PaidAmount),0) PaidAmount, 
				ISNULL(SUM(rd.OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(rd.WritenOffAmount),0) WritenOffAmount,
				COUNT(rd.BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.InsuranceCompanyName, d.DayName, d.DayOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		
		SELECT	'W-' + CAST(d.WeekOfMonth AS VARCHAR) TimePeriod,
				D.WeekOfMonth PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount,  
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.InsuranceCompanyName, d.WeekOfMonth
		
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		
		SELECT	'W-' + CAST(d.WeekOfMonth AS VARCHAR) TimePeriod,
				D.WeekOfMonth PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.InsuranceCompanyName, d.WeekOfMonth
		
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		SELECT	'W-' + CAST(d.WeekOfQuarter AS VARCHAR) TimePeriod,
				D.WeekOfQuarter PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.InsuranceCompanyName, d.WeekOfQuarter
		
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		
		SELECT	d.MonthNameShort TimePeriod,
				D.Month PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.InsuranceCompanyName, d.MonthNameShort, d.Month
	END
	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		SELECT	d.MonthNameShort TimePeriod,
				D.Month PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount,
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.InsuranceCompanyName, d.MonthNameShort, d.Month
	END
	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		SELECT	d.MonthNameShort TimePeriod,
				D.Month PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY  d.MonthNameShort, d.Month, rd.InsuranceCompanyName
	END
	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		SELECT	'Q-' + CAST(d.Quarter AS VARCHAR) TimePeriod,
				D.Quarter PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount,
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.InsuranceCompanyName, d.Quarter
	END
	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		SELECT	'Q-' + CAST(d.Quarter AS VARCHAR) TimePeriod,
				D.Quarter PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.InsuranceCompanyName, d.Quarter
	END
	ELSE IF(@Interval = 'Yearly' AND ( @Period = 'Last Year' or @Period = 'This Year'))
	BEGIN
		SELECT	d.Year TimePeriod,
				D.Year PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.InsuranceCompanyName, d.Year
	END
	ELSE IF(@Interval = 'Yearly' AND @Period = 'Last 5 Years')
	BEGIN
		SELECT	d.Year TimePeriod,
				D.Year PeriodNumber,
				rd.InsuranceCompanyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.InsuranceCompanyName, d.Year
	END
END
GO

------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [Report].[DashboardGetTotalRevenueByProviderDATA] 
	@Companyies NVARCHAR(MAX) = null,
	@Specialties NVARCHAR(MAX) = null,
	@InsuranceNames NVARCHAR(MAX) = null,
	@ProvideNames NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@CaseType NVARCHAR(MAX) = null,
	@Interval VARCHAR(50) = null,
	@Period VARCHAR(100) = null,
	@ToDate DATETIME = null,
	@FromDate DATETIME = null

AS
BEGIN
	
	IF(@ToDate IS NULL OR @ToDate = '')
	BEGIN
		SET @ToDate  = CONVERT(DATETIME, CONVERT(VARCHAR(10), GETDATE(), 103 ), 103)
	END

	IF(@FromDate IS NULL OR @FromDate = '')
	BEGIN
		SET	@FromDate  = 
			CASE 
				WHEN @Period = 'Last Week' THEN DATEADD(WEEK, -1, @ToDate)
				WHEN @Period = 'Last Month' THEN DATEADD(MONTH, -1, @ToDate)
				WHEN @Period = 'Last Quarter' THEN DATEADD(MONTH, -3, @ToDate)
				WHEN @Period = 'Last Year' THEN DATEADD(YEAR, -1, @ToDate)
				WHEN @Period = 'Last 5 Years' THEN DATEADD(YEAR, -5, @ToDate)
			END	
	END

	
	DECLARE @AccountFilter TABLE(AccountIDCheckSum INT PRIMARY KEY)
	INSERT @AccountFilter(AccountIDCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@Companyies, ',')

	DECLARE @CaseTypeFilter TABLE(CaseTypeIdCheckSum INT PRIMARY KEY)
	INSERT @CaseTypeFilter(CaseTypeIdCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@CaseType, ',')

	IF(@Interval = 'Daily' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		
		SELECT	LEFT(d.DayName,3) TimePeriod,
				d.DayOfMonth PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(rd.PaidAmount),0) PaidAmount, 
				ISNULL(SUM(rd.OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(rd.WritenOffAmount),0) WritenOffAmount,
				COUNT(rd.BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.ProviderName, d.DayName, d.DayOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		
		SELECT	'W-' + CAST(d.WeekOfMonth AS VARCHAR) TimePeriod,
				D.WeekOfMonth PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount,  
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.ProviderName, d.WeekOfMonth
		
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		
		SELECT	'W-' + CAST(d.WeekOfMonth AS VARCHAR) TimePeriod,
				D.WeekOfMonth PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.ProviderName, d.WeekOfMonth
		
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		SELECT	'W-' + CAST(d.WeekOfQuarter AS VARCHAR) TimePeriod,
				D.WeekOfQuarter PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.ProviderName, d.WeekOfQuarter
		
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		
		SELECT	d.MonthNameShort TimePeriod,
				D.Month PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.ProviderName, d.MonthNameShort, d.Month
	END
	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		SELECT	d.MonthNameShort TimePeriod,
				D.Month PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount,
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.ProviderName, d.MonthNameShort, d.Month
	END
	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		SELECT	d.MonthNameShort TimePeriod,
				D.Month PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY  d.MonthNameShort, d.Month, rd.ProviderName
	END
	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		SELECT	'Q-' + CAST(d.Quarter AS VARCHAR) TimePeriod,
				D.Quarter PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount,
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.ProviderName, d.Quarter
	END
	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		SELECT	'Q-' + CAST(d.Quarter AS VARCHAR) TimePeriod,
				D.Quarter PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.ProviderName, d.Quarter
	END
	ELSE IF(@Interval = 'Yearly' AND ( @Period = 'Last Year' or @Period = 'This Year'))
	BEGIN
		SELECT	d.Year TimePeriod,
				D.Year PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.ProviderName, d.Year
	END
	ELSE IF(@Interval = 'Yearly' AND @Period = 'Last 5 Years')
	BEGIN
		SELECT	d.Year TimePeriod,
				D.Year PeriodNumber,
				rd.ProviderName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.ProviderName, d.Year
	END
END
GO



----------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [Report].[DashboardGetTotalRevenueBySpecialtyDATA] 
	@Companyies NVARCHAR(MAX) = null,
	@Specialties NVARCHAR(MAX) = null,
	@InsuranceNames NVARCHAR(MAX) = null,
	@ProvideNames NVARCHAR(MAX) = null,
	@DoctorNames NVARCHAR(MAX) = null,
	@ProviderLocation NVARCHAR(MAX) = null,
	@CaseType NVARCHAR(MAX) = null,
	@Interval VARCHAR(50) = null,
	@Period VARCHAR(100) = null,
	@ToDate DATETIME = null,
	@FromDate DATETIME = null

AS
BEGIN
	
	IF(@ToDate IS NULL OR @ToDate = '')
	BEGIN
		SET @ToDate  = CONVERT(DATETIME, CONVERT(VARCHAR(10), GETDATE(), 103 ), 103)
	END

	IF(@FromDate IS NULL OR @FromDate = '')
	BEGIN
		SET	@FromDate  = 
			CASE 
				WHEN @Period = 'Last Week' THEN DATEADD(WEEK, -1, @ToDate)
				WHEN @Period = 'Last Month' THEN DATEADD(MONTH, -1, @ToDate)
				WHEN @Period = 'Last Quarter' THEN DATEADD(MONTH, -3, @ToDate)
				WHEN @Period = 'Last Year' THEN DATEADD(YEAR, -1, @ToDate)
				WHEN @Period = 'Last 5 Years' THEN DATEADD(YEAR, -5, @ToDate)
			END	
	END

	--Select @FromDate fromDate , @ToDate ToDate
	
	DECLARE @AccountFilter TABLE(AccountIDCheckSum INT PRIMARY KEY)
	INSERT @AccountFilter(AccountIDCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@Companyies, ',')

	DECLARE @CaseTypeFilter TABLE(CaseTypeIdCheckSum INT PRIMARY KEY)
	INSERT @CaseTypeFilter(CaseTypeIdCheckSum)
	SELECT BINARY_CHECKSUM(UPPER(VALUE)) FROM Report.fn_Split(@CaseType, ',')

	IF(@Interval = 'Daily' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		
		SELECT	LEFT(d.DayName,3) TimePeriod,
				d.DayOfMonth PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(rd.PaidAmount),0) PaidAmount, 
				ISNULL(SUM(rd.OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(rd.WritenOffAmount),0) WritenOffAmount,
				COUNT(rd.BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.SpecialtyName, d.DayName, d.DayOfMonth
	END
	ELSE IF(@Interval = 'Weekly' AND ( @Period = 'Last Week' OR @Period = 'This Week'))
	BEGIN
		
		SELECT	'W-' + CAST(d.WeekOfMonth AS VARCHAR) TimePeriod,
				D.WeekOfMonth PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount,  
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.SpecialtyName, d.WeekOfMonth
		
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		
		SELECT	'W-' + CAST(d.WeekOfMonth AS VARCHAR) TimePeriod,
				D.WeekOfMonth PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.SpecialtyName, d.WeekOfMonth
		
	END

	ELSE IF(@Interval = 'Weekly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		SELECT	'W-' + CAST(d.WeekOfQuarter AS VARCHAR) TimePeriod,
				D.WeekOfQuarter PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.SpecialtyName, d.WeekOfQuarter
		
	END

	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Month' OR @Period = 'This Month'))
	BEGIN
		
		SELECT	d.MonthNameShort TimePeriod,
				D.Month PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.SpecialtyName, d.MonthNameShort, d.Month
	END
	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		SELECT	d.MonthNameShort TimePeriod,
				D.Month PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount,
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.SpecialtyName, d.MonthNameShort, d.Month
	END
	ELSE IF(@Interval = 'Monthly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		SELECT	d.MonthNameShort TimePeriod,
				D.Month PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY  d.MonthNameShort, d.Month, rd.SpecialtyName
	END
	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Quarter' OR @Period = 'This Quarter'))
	BEGIN
		SELECT	'Q-' + CAST(d.Quarter AS VARCHAR) TimePeriod,
				D.Quarter PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount,
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.SpecialtyName, d.Quarter
	END
	ELSE IF(@Interval = 'Quarterly' AND (@Period = 'Last Year' OR @Period = 'This Year'))
	BEGIN
		SELECT	'Q-' + CAST(d.Quarter AS VARCHAR) TimePeriod,
				D.Quarter PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				BillCount = COUNT(BillNumber)
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.SpecialtyName, d.Quarter
	END
	ELSE IF(@Interval = 'Yearly' AND ( @Period = 'Last Year' or @Period = 'This Year'))
	BEGIN
		SELECT	d.Year TimePeriod,
				D.Year PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.SpecialtyName, d.Year
	END
	ELSE IF(@Interval = 'Yearly' AND @Period = 'Last 5 Years')
	BEGIN
		SELECT	d.Year TimePeriod,
				D.Year PeriodNumber,
				rd.SpecialtyName,
				ISNULL(SUM(BillAmount),0) Amount,
				ISNULL(SUM(PaidAmount),0) PaidAmount, 
				ISNULL(SUM(OutstandingAmount),0) OutstandingAmount,
				ISNULL(SUM(WritenOffAmount),0) WritenOffAmount,
				COUNT(BillNumber) BillCount
		FROM	[Report].[DimDate] d WITH (NOLOCK)
		JOIN	[Report].[FactBills] RD WITH (NOLOCK) ON rd.BillDate = d.Date
		WHERE	(@Specialties IS NULL OR rd.SpecialtyCheckSum IN (SELECT VALUE FROM Report.fn_Split(@Specialties, ',')))
		AND		(@Companyies IS NULL OR rd.AccountIDCheckSum IN (SELECT AccountIDCheckSum FROM @AccountFilter))
		AND		(@InsuranceNames IS NULL OR rd.InsuranceCheckSum IN (SELECT VALUE FROM Report.fn_Split(@InsuranceNames, ',')))
		AND		(@ProvideNames IS NULL OR rd.ProviderCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProvideNames, ',')))
		AND		(@DoctorNames IS NULL OR rd.DoctorNameCheckSum IN (SELECT VALUE FROM Report.fn_Split(@DoctorNames,',')))
		AND		(@ProviderLocation IS NULL OR rd.ProviderLocationCheckSum IN (SELECT VALUE FROM Report.fn_Split(@ProviderLocation,',')))
		AND		(@CaseType IS NULL OR rd.CaseTypeIdCheckSum IN (SELECT CaseTypeIdCheckSum FROM @CaseTypeFilter))
		AND		rd.BillDate >= @FromDate
		AND		rd.BillDate <= @ToDate
		GROUP	BY rd.SpecialtyName, d.Year
	END
END
GO


------------------------------------------------------------------------------------------------------------------------------------
